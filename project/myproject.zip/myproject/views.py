# myapp/views.py

from django.http import HttpResponse
from django.contrib.auth import get_user_model, authenticate
from django.db import connection
from rest_framework.views import APIView
from rest_framework.response import Response
from .serializers import UserSerializer
from rest_framework_simplejwt.views import TokenObtainPairView as JWTTokenObtainPairView, TokenRefreshView as JWTTokenRefreshView
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.tokens import AccessToken
from rest_framework_simplejwt.exceptions import TokenError
from django.conf import settings

User = get_user_model()
try:
    from rolepermissions.decorators import has_role
except Exception:
    # rolepermissions may not import cleanly in this environment; provide
    # a no-op fallback so management commands still work.
    def has_role(*args, **kwargs):
        def _decorator(func):
            return func
        return _decorator
from rest_framework import status
from django.db import connection
from django.utils import timezone
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.hashers import make_password
import tempfile
import subprocess
import os
import logging
import traceback
import sys
import zipfile
import re
import shutil
import binascii
import time

# module logger
logger = logging.getLogger(__name__)


def _safe_rmtree(path, retries=6, delay=0.25):
    """Remove directory tree with retries to handle Windows file locks."""
    last_exc = None
    for attempt in range(retries):
        try:
            shutil.rmtree(path)
            return
        except Exception as e:
            last_exc = e
            time.sleep(delay * (attempt + 1))
    # final attempt with onerror handler
    def _onerror(func, p, exc_info):
        try:
            os.chmod(p, 0o700)
            func(p)
        except Exception:
            pass
    try:
        shutil.rmtree(path, onerror=_onerror)
    except Exception:
        logger.warning('Failed to remove path %s after retries: %s', path, str(last_exc))
 
def home(request):
    return HttpResponse('OK')


# Helper: format number with dot thousands separator, e.g. 1000000 -> '1.000.000'
def format_number_dot(val):
    if val is None:
        return val
    try:
        s = str(val).strip()
        if s == '':
            return ''
        s = s.replace(',', '.')
        num = float(s)
        if abs(num - int(num)) < 1e-9:
            n = int(num)
            return format(n, ',').replace(',', '.')
        whole = int(num)
        frac = abs(num - whole)
        frac_str = ('%.2f' % frac)[2:]
        return format(whole, ',').replace(',', '.') + '.' + frac_str
    except Exception:
        return val


def number_to_indonesian_words(val):
    units = ['', 'satu','dua','tiga','empat','lima','enam','tujuh','delapan','sembilan']

    def spell_int(n):
        n = int(n)
        if n < 10:
            return units[n]
        if n < 20:
            if n == 10:
                return 'sepuluh'
            if n == 11:
                return 'sebelas'
            return units[n-10] + ' belas'
        if n < 100:
            tens = n // 10
            rest = n % 10
            return (units[tens] + ' puluh' + (' ' + units[rest] if rest else '')).strip()
        if n < 200:
            return 'seratus' + (' ' + spell_int(n-100) if n-100 else '')
        if n < 1000:
            hundreds = n // 100
            rest = n % 100
            return (units[hundreds] + ' ratus' + (' ' + spell_int(rest) if rest else '')).strip()
        if n < 2000:
            return 'seribu' + (' ' + spell_int(n-1000) if n-1000 else '')
        if n < 1000000:
            thousands = n // 1000
            rest = n % 1000
            return (spell_int(thousands) + ' ribu' + (' ' + spell_int(rest) if rest else '')).strip()
        if n < 1000000000:
            millions = n // 1000000
            rest = n % 1000000
            return (spell_int(millions) + ' juta' + (' ' + spell_int(rest) if rest else '')).strip()
        if n < 1000000000000:
            billions = n // 1000000000
            rest = n % 1000000000
            return (spell_int(billions) + ' miliar' + (' ' + spell_int(rest) if rest else '')).strip()
        return str(n)

    try:
        s = str(val).strip()
        if s == '':
            return ''
        s = s.replace(',', '.')
        if '.' in s:
            int_part, dec_part = s.split('.', 1)
            int_words = spell_int(int(int_part)) if int_part and int(int_part) != 0 else 'nol' if int_part == '0' else ''
            dec_words = ' '.join([units[int(d)] if d.isdigit() else d for d in dec_part])
            if int_words:
                return (int_words + ' koma ' + dec_words).strip()
            else:
                return ('koma ' + dec_words).strip()
        else:
            return spell_int(int(float(s)))
    except Exception:
        return str(val)


def date_to_indonesian_words(val):
    from datetime import datetime, date
    months = ['januari','februari','maret','april','mei','juni','juli','agustus','september','oktober','november','desember']
    if val is None:
        return ''
    try:
        if isinstance(val, (datetime,)):
            d = val.date()
        elif isinstance(val, date):
            d = val
        else:
            s = str(val).strip()
            if not s:
                return ''
            try:
                d = datetime.fromisoformat(s).date()
            except Exception:
                try:
                    d = datetime.strptime(s, '%Y-%m-%d').date()
                except Exception:
                    return ''
        day_word = number_to_indonesian_words(d.day)
        month_word = months[d.month-1]
        year_word = number_to_indonesian_words(d.year)
        return f"{day_word} {month_word} {year_word}"
    except Exception:
        return ''


class SimpleLoginView(APIView):
    """
    Simple login endpoint that checks credentials against `auth_user` table
    and returns JWT tokens. Kept minimal and raw-SQL to avoid ORM differences.
    """
    permission_classes = []

    def post(self, request):
        from django.contrib.auth.hashers import check_password
        from rest_framework_simplejwt.tokens import RefreshToken

        username = request.data.get('username')
        password = request.data.get('password')

        if not username or not password:
            return Response({'error': 'Username dan password harus diisi'}, status=status.HTTP_400_BAD_REQUEST)

        with connection.cursor() as cursor:
            cursor.execute('SELECT id, username, password, email, full_name, role, is_staff FROM auth_user WHERE username=%s', [username])
            row = cursor.fetchone()

        if not row:
            return Response({'error': 'Username atau password salah'}, status=status.HTTP_401_UNAUTHORIZED)

        user_id, db_username, db_password, db_email, db_full_name, db_role, db_is_staff = row

        if not check_password(password, db_password):
            return Response({'error': 'Username atau password salah'}, status=status.HTTP_401_UNAUTHORIZED)

        refresh = RefreshToken()
        refresh['user_id'] = user_id
        refresh['username'] = db_username
        access_token = refresh.access_token

        return Response({
            'access': str(access_token),
            'refresh': str(refresh),
            'user': {
                'id': user_id,
                'username': db_username,
                'email': db_email,
                'full_name': db_full_name,
                'role': db_role,
                'is_staff': bool(db_is_staff),
            }
        }, status=status.HTTP_200_OK)


class RegisterView(APIView):
    def post(self, request):
        serializer = UserSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'message': 'User created successfully'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class UserListCreateView(APIView):
    # Allow anonymous POSTs so frontend can create SP3 rows without requiring auth
    permission_classes = [AllowAny]
    # Bypass default authentication classes for this view to avoid 401 on anonymous POSTs
    authentication_classes = []

    def get(self, request):
        try:
            with connection.cursor() as cursor:
                cursor.execute("SELECT id, username, email, full_name, role FROM auth_user ORDER BY username")
                cols = [c[0] for c in cursor.description] if cursor.description else []
                rows = cursor.fetchall()
                users = [dict(zip(cols, r)) for r in rows]
            return Response({'users': users}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def post(self, request):
        # create via serializer when available
        serializer = UserSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'message': 'User created successfully'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class UserDetailView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, username):
        try:
            with connection.cursor() as cursor:
                cursor.execute('SELECT * FROM auth_user WHERE username=%s LIMIT 1', [username])
                cols = [c[0] for c in cursor.description] if cursor.description else []
                row = cursor.fetchone()
                user = dict(zip(cols, row)) if row else None
            if not user:
                return Response({'error': 'User not found'}, status=status.HTTP_404_NOT_FOUND)
            return Response({'user': user}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def put(self, request, username):
        # basic update: allow email, full_name, password, role, phone
        data = request.data or {}
        allowed = ['email', 'full_name', 'password', 'role', 'phone']
        fields = []
        params = []
        try:
            if 'password' in data and data.get('password'):
                hashed = make_password(data.get('password'))
                fields.append('password=%s')
                params.append(hashed)
            for k in allowed:
                if k == 'password':
                    continue
                if k in data:
                    fields.append(f"{k}=%s")
                    params.append(data.get(k))
            if not fields:
                return Response({'message': 'No fields to update'}, status=status.HTTP_200_OK)
            params.append(username)
            sql = 'UPDATE auth_user SET ' + ', '.join(fields) + ' WHERE username=%s'
            with connection.cursor() as cursor:
                cursor.execute(sql, params)
                cursor.execute('SELECT id, username, email, full_name, role FROM auth_user WHERE username=%s', [username])
                cols = [c[0] for c in cursor.description] if cursor.description else []
                row = cursor.fetchone()
                user = dict(zip(cols, row)) if row else None
            return Response({'user': user, 'message': 'User updated'}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)


class CustomTokenObtainPairView(JWTTokenObtainPairView):
    permission_classes = []
    pass


class CustomTokenRefreshView(JWTTokenRefreshView):
    pass


class ProtectedView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = getattr(request, 'user', None)
        return Response({
            'message': 'Welcome to the dashboard',
            'user': getattr(user, 'username', None),
            'full_name': getattr(user, 'full_name', getattr(user, 'username', None)),
            'role': getattr(user, 'role', 'User'),
            'email': getattr(user, 'email', None),
        })


class DashboardSummaryView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        # Return simple counts; if tables missing, return 0
        def safe_count(table_name):
            try:
                with connection.cursor() as cursor:
                    cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
                    row = cursor.fetchone()
                    return int(row[0]) if row and row[0] is not None else 0
            except Exception:
                return 0

        data = {
            'bl_agreement': safe_count('bl_agreement'),
            'bl_sp3': safe_count('bl_sp3'),
            'uv_agreement': safe_count('uv_agreement'),
            'uv_sp3': safe_count('uv_sp3'),
        }
        return Response(data)


class UVAgreementView(APIView):
    """
    Mirrors BLAgreementView behavior but operates on uv_agreement and uv_collateral tables.
    This keeps BL endpoints untouched while providing the same save/list/get semantics
    for UV agreements.
    """
    permission_classes = [IsAuthenticated]

    def post(self, request):
        data = request.data
        contract_number = data.get('contract_number')
        branch_id = data.get('branch_id')
        director = data.get('director')
        bm_data = data.get('bm_data', {})
        contract_data = data.get('contract_data', {})
        collateral_data = data.get('collateral_data', {})
        header_fields = data.get('header_fields', {})

        try:
            with connection.cursor() as cursor:
                cursor.execute("SHOW COLUMNS FROM uv_agreement")
                cols_meta = cursor.fetchall()
                cols_info = [row[0] for row in cols_meta]
                cols_lookup = {c.lower(): c for c in cols_info}

                data_map = {}
                if contract_number:
                    data_map['contract_number'] = contract_number

                client_created_by = data.get('created_by')
                if client_created_by and 'created_by' in cols_info:
                    data_map['created_by'] = client_created_by

                user_full_name = None
                user_username = None
                if getattr(request, 'user', None) and getattr(request.user, 'is_authenticated', False):
                    user_full_name = getattr(request.user, 'full_name', None)
                    user_username = getattr(request.user, 'username', None)
                    if (not user_full_name or not user_username) and getattr(request.user, 'id', None):
                        try:
                            u = User.objects.filter(pk=request.user.id).first()
                            if u:
                                user_full_name = user_full_name or getattr(u, 'full_name', None)
                                user_username = user_username or getattr(u, 'username', None)
                        except Exception:
                            pass
                else:
                    auth_header = request.META.get('HTTP_AUTHORIZATION', '')
                    if auth_header and auth_header.startswith('Bearer '):
                        token = auth_header.split(' ', 1)[1].strip()
                        try:
                            payload = AccessToken(token)
                            user_id = payload.get('user_id') or payload.get('uid') or payload.get('id')
                            if user_id:
                                try:
                                    u = User.objects.filter(pk=user_id).first()
                                    if u:
                                        user_full_name = user_full_name or getattr(u, 'full_name', None)
                                        user_username = user_username or getattr(u, 'username', None)
                                except Exception:
                                    pass
                        except TokenError:
                            pass

                user_username = user_username or (user_full_name and user_full_name.replace(' ', '').lower()) or 'anonymous'
                now = timezone.now()

                if branch_id is not None and 'branch_id' in cols_lookup:
                    data_map[cols_lookup['branch_id']] = branch_id
                if director is not None:
                    if 'name_of_director' in cols_lookup:
                        data_map[cols_lookup['name_of_director']] = director
                    elif 'director' in cols_lookup:
                        data_map[cols_lookup['director']] = director

                branch_data = data.get('branch_data', {})
                for src in (bm_data, branch_data, contract_data, collateral_data, header_fields):
                    if not isinstance(src, dict):
                        continue
                    for k, v in src.items():
                        key = str(k).lower()
                        if key == 'name_of_director':
                            key = 'name_of_director'
                        if key in cols_lookup:
                            data_map[cols_lookup[key]] = v

                from datetime import datetime, date as _date
                field_type_map = {row[0]: row[1].lower() for row in cols_meta}
                for k in list(data_map.keys()):
                    ft = field_type_map.get(k, '')
                    if not any(t in ft for t in ('date', 'timestamp', 'datetime')):
                        continue
                    val = data_map.get(k)
                    if val is None or (isinstance(val, str) and val.strip() == ''):
                        data_map.pop(k, None)
                        continue
                    if isinstance(val, (_date, datetime)):
                        continue
                    s = str(val).strip()
                    parsed = None
                    try:
                        try:
                            parsed = datetime.fromisoformat(s)
                        except Exception:
                            import re
                            if re.match(r'^\s*\d{1,2}\s+\d{1,2}\s+\d{4}\s*$', s):
                                s = re.sub(r'\s+', '/', s.strip())
                            for fmt in ('%Y-%m-%d', '%d-%m-%Y', '%d/%m/%Y', '%Y/%m/%d', '%d %m %Y', '%d %b %Y', '%d %B %Y'):
                                try:
                                    parsed = datetime.strptime(s, fmt)
                                    break
                                except Exception:
                                    continue
                        if parsed is None:
                            data_map.pop(k, None)
                            continue
                        if 'date' in ft and 'time' not in ft and 'datetime' not in ft:
                            data_map[k] = parsed.date()
                        else:
                            if parsed.tzinfo is None:
                                parsed = timezone.make_aware(parsed)
                            data_map[k] = parsed
                    except Exception:
                        data_map.pop(k, None)

                if 'id' in data_map:
                    data_map.pop('id', None)

                field_type_map = {row[0]: row[1].lower() for row in cols_meta}
                for _f in ('admin_rate', 'tlo', 'life_insurance'):
                    if _f in cols_lookup and cols_lookup[_f] not in data_map:
                        ftype = field_type_map.get(_f, '')
                        if any(t in ftype for t in ('int', 'decimal', 'float', 'double')):
                            if 'decimal' in ftype or 'float' in ftype or 'double' in ftype:
                                data_map[cols_lookup[_f]] = 0.0
                            else:
                                data_map[cols_lookup[_f]] = 0
                        else:
                            data_map[cols_lookup[_f]] = '-'

                for col_row in cols_meta:
                    field_name = col_row[0]
                    field_type = col_row[1].lower()
                    is_nullable = col_row[2]
                    default_val = col_row[4]
                    if field_name in data_map:
                        continue
                    if field_name in ('id', 'created_by', 'created_at', 'update_at'):
                        continue
                    if is_nullable == 'NO' and default_val is None:
                        if any(t in field_type for t in ('int', 'decimal', 'float', 'double')):
                            data_map[field_name] = 0
                        elif any(t in field_type for t in ('date', 'timestamp', 'datetime')):
                            data_map[field_name] = timezone.now()
                        else:
                            data_map[field_name] = '-'

                existing_check_sql = "SELECT contract_number FROM uv_agreement WHERE contract_number=%s"
                exists = None
                if contract_number:
                    cursor.execute(existing_check_sql, [contract_number])
                    exists = cursor.fetchone()

                edit_only = bool(data.get('edit_only'))
                create_only = bool(data.get('create_only'))

                if exists:
                    if create_only:
                        return Response({'error': 'Record already exists (create_only specified)'}, status=status.HTTP_400_BAD_REQUEST)
                    if 'update_at' in cols_info:
                        data_map['update_at'] = now
                    data_map.pop('created_by', None)
                    data_map.pop('created_at', None)
                    set_cols = []
                    params = []
                    for col, val in data_map.items():
                        if col == 'contract_number':
                            continue
                        set_cols.append(f"{col}=%s")
                        params.append(val)
                    if set_cols:
                        sql = f"UPDATE uv_agreement SET {', '.join(set_cols)} WHERE contract_number=%s"
                        params.append(contract_number)
                        cursor.execute(sql, params)
                else:
                    if edit_only:
                        return Response({'error': 'Record not found for update (edit_only specified)'}, status=status.HTTP_400_BAD_REQUEST)
                    if 'created_by' in cols_info and user_username:
                        data_map['created_by'] = user_username
                    if 'created_at' in cols_info:
                        data_map[cols_lookup['created_at']] = now if 'created_at' in cols_lookup else now
                    cols = []
                    placeholders = []
                    params = []
                    for col, val in data_map.items():
                        cols.append(col)
                        placeholders.append('%s')
                        params.append(val)
                    sql = f"INSERT INTO uv_agreement ({', '.join(cols)}) VALUES ({', '.join(placeholders)})"
                    cursor.execute(sql, params)

            return Response({'message': 'Data UV berhasil disimpan'}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def get(self, request):
        contract_number = request.query_params.get('contract_number', '').strip()
        try:
            with connection.cursor() as cursor:
                if not contract_number:
                    # Build a safe SELECT list from actual uv_agreement columns to avoid
                    # referencing missing columns (e.g. collateral_type may not exist).
                    cursor.execute("SHOW COLUMNS FROM uv_agreement")
                    cols_meta_short = cursor.fetchall()
                    available_cols = [r[0] for r in cols_meta_short]

                    # inspect uv_collateral for vehicle-like columns to coalesce
                    cursor.execute("SHOW COLUMNS FROM uv_collateral")
                    coll_meta = cursor.fetchall()
                    coll_cols = [r[0] for r in coll_meta]

                    preferred = ['agreement_date', 'contract_number', 'name_of_debtor', 'nik_number_of_debtor', 'vehicle_types', 'vechile_types', 'collateral_type', 'uv_collateral_type', 'created_by']

                    select_parts = []
                    # Always include contract_number
                    if 'contract_number' in available_cols:
                        select_parts.append('uv_agreement.contract_number')

                    # include agreement_date and other preferred columns from uv_agreement if present
                    for p in preferred:
                        if p == 'contract_number':
                            continue
                        if p in available_cols and p not in ('vehicle_types', 'vechile_types', 'collateral_type', 'uv_collateral_type'):
                            select_parts.append(f'uv_agreement.{p}')

                    # Build a COALESCE for vehicle types using uv_agreement then uv_collateral
                    coalesce_sources = []
                    if 'vehicle_types' in available_cols:
                        coalesce_sources.append('uv_agreement.vehicle_types')
                    if 'vechile_types' in available_cols:
                        coalesce_sources.append('uv_agreement.vechile_types')
                    # from uv_collateral prefixed with alias uc
                    for candidate in ('vehicle_types', 'vechile_types', 'collateral_type', 'uv_collateral_type'):
                        if candidate in coll_cols:
                            coalesce_sources.append(f'uc.{candidate}')

                    if coalesce_sources:
                        select_parts.append('COALESCE(' + ', '.join(coalesce_sources) + ') AS vehicle_types')

                    # include created_by if present
                    if 'created_by' in available_cols:
                        select_parts.append('uv_agreement.created_by')

                    if not select_parts:
                        # fallback: select contract_number only
                        select_clause = 'uv_agreement.contract_number'
                    else:
                        select_clause = ', '.join(select_parts)

                    sql = f"SELECT {select_clause} FROM uv_agreement LEFT JOIN uv_collateral uc ON uv_agreement.contract_number = uc.contract_number ORDER BY COALESCE(uv_agreement.agreement_date, uv_agreement.created_at) DESC"
                    cursor.execute(sql)
                    cols = [c[0] for c in cursor.description] if cursor.description else []
                    rows = cursor.fetchall()
                    items = [dict(zip(cols, r)) for r in rows]
                    return Response({'agreements': items}, status=status.HTTP_200_OK)

                cursor.execute(
                    "SELECT * FROM uv_agreement WHERE LOWER(contract_number) = LOWER(%s) LIMIT 1",
                    [contract_number]
                )
                cols = [col[0] for col in cursor.description] if cursor.description else []
                uv_row = cursor.fetchone()
                uv_data = dict(zip(cols, uv_row)) if uv_row else None

                cursor.execute(
                    "SELECT * FROM uv_collateral WHERE LOWER(contract_number) = LOWER(%s) LIMIT 1",
                    [contract_number]
                )
                collateral_columns = [col[0] for col in cursor.description] if cursor.description else []
                uv_collateral_row = cursor.fetchone()
                collateral_data = dict(zip(collateral_columns, uv_collateral_row)) if uv_collateral_row else None

                if uv_data:
                    try:
                        if 'name_of_director' in uv_data and 'Name_of_director' not in uv_data:
                            uv_data['Name_of_director'] = uv_data.get('name_of_director')
                    except Exception:
                        pass
                    return Response({'debtor': uv_data, 'collateral': collateral_data}, status=status.HTTP_200_OK)

                cursor.execute(
                    "SELECT * FROM contract WHERE LOWER(contract_number) = LOWER(%s) LIMIT 1",
                    [contract_number]
                )
                columns = [col[0] for col in cursor.description] if cursor.description else []
                contract_row = cursor.fetchone()
                debtor_data = dict(zip(columns, contract_row)) if contract_row else None

                if not debtor_data and not collateral_data:
                    return Response({'debtor': None, 'collateral': None, 'message': 'Data tidak ditemukan untuk nomor kontrak ini'}, status=status.HTTP_404_NOT_FOUND)

                return Response({'debtor': debtor_data, 'collateral': collateral_data}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': f'Error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)



class UVCollateralCreateView(APIView):
    """Create or update UV collateral rows (mirrors BL collateral handler semantics)."""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        """Allow frontend to lookup uv_collateral rows by contract_number via GET.
        Returns JSON: { "collateral": [ { ... }, ... ] }
        """
        contract_number = request.query_params.get('contract_number') or request.GET.get('contract_number')
        if not contract_number:
            return Response({'error': 'contract_number query parameter required'}, status=status.HTTP_400_BAD_REQUEST)
        try:
            with connection.cursor() as cursor:
                cursor.execute("SHOW COLUMNS FROM uv_collateral")
                cols_meta = cursor.fetchall()
                cols_info = [row[0] for row in cols_meta]
                sql = f"SELECT {', '.join(cols_info)} FROM uv_collateral WHERE LOWER(contract_number)=LOWER(%s)"
                cursor.execute(sql, [contract_number])
                rows = cursor.fetchall()
                result = []
                for row in rows:
                    row_dict = {cols_info[i]: row[i] for i in range(len(cols_info))}
                    result.append(row_dict)
                return Response({'collateral': result}, status=status.HTTP_200_OK)
        except Exception as e:
            logger.exception('UVCollateral lookup failed')
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def post(self, request):
        data = request.data
        contract_number = data.get('contract_number')
        collateral = data.get('collateral', {})
        if not contract_number:
            return Response({'error': 'contract_number is required'}, status=status.HTTP_400_BAD_REQUEST)

        try:
            with connection.cursor() as cursor:
                cursor.execute("SHOW COLUMNS FROM uv_collateral")
                cols_meta = cursor.fetchall()
                cols_info = [r[0] for r in cols_meta]
                cols_lookup = {c.lower(): c for c in cols_info}

                data_map = {'contract_number': contract_number}
                if isinstance(collateral, dict):
                    for k, v in collateral.items():
                        key = str(k).lower()
                        if key in cols_lookup:
                            data_map[cols_lookup[key]] = v

                for col_row in cols_meta:
                    field_name = col_row[0]
                    field_type = col_row[1].lower()
                    is_nullable = col_row[2]
                    default_val = col_row[4]
                    if field_name in data_map:
                        continue
                    if field_name in ('id', 'created_by', 'created_at', 'update_at'):
                        continue
                    if is_nullable == 'NO' and default_val is None:
                        if any(t in field_type for t in ('int', 'decimal', 'float', 'double')):
                            data_map[field_name] = 0
                        elif any(t in field_type for t in ('date', 'timestamp', 'datetime')):
                            data_map[field_name] = timezone.now()
                        else:
                            data_map[field_name] = '-'

                cursor.execute("SELECT contract_number FROM uv_collateral WHERE contract_number=%s LIMIT 1", [contract_number])
                exists = cursor.fetchone()
                if exists:
                    set_cols = []
                    params = []
                    for col, val in data_map.items():
                        if col == 'contract_number':
                            continue
                        set_cols.append(f"{col}=%s")
                        params.append(val)
                    if set_cols:
                        sql = f"UPDATE uv_collateral SET {', '.join(set_cols)} WHERE contract_number=%s"
                        params.append(contract_number)
                        cursor.execute(sql, params)
                else:
                    cols = []
                    placeholders = []
                    params = []
                    for col, val in data_map.items():
                        cols.append(col)
                        placeholders.append('%s')
                        params.append(val)
                    sql = f"INSERT INTO uv_collateral ({', '.join(cols)}) VALUES ({', '.join(placeholders)})"
                    cursor.execute(sql, params)

            return Response({'message': 'UV collateral saved'}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    permission_classes = [IsAuthenticated]

    def put(self, request, username):
        # Resolve target user id
        try:
            if str(username).isdigit():
                target_id = int(username)
            else:
                with connection.cursor() as cursor:
                    cursor.execute('SELECT id FROM auth_user WHERE username=%s', [username])
                    row = cursor.fetchone()
                    target_id = row[0] if row else None
            if not target_id:
                return Response({'error': 'User not found'}, status=status.HTTP_404_NOT_FOUND)
        except Exception:
            return Response({'error': 'User not found'}, status=status.HTTP_404_NOT_FOUND)

        # Collect fields to update
        fields = []
        params = []

        email = request.data.get('email')
        password = request.data.get('password')
        role = request.data.get('role')
        phone = request.data.get('phone')
        employee_id = request.data.get('employee_id')
        region_id = request.data.get('region_id')
        area_id = request.data.get('area_id')
        branch_id = request.data.get('branch_id')
        full_name = request.data.get('full_name')
        is_active = request.data.get('is_active')

        # Email duplicate check
        if email is not None:
            with connection.cursor() as cursor:
                cursor.execute('SELECT id FROM auth_user WHERE email=%s AND id<>%s', [email, target_id])
                if cursor.fetchone():
                    return Response({'error': 'Email already exists'}, status=status.HTTP_400_BAD_REQUEST)
            fields.append('email=%s')
            params.append(email)

        if password:
            hashed = make_password(password)
            fields.append('password=%s')
            params.append(hashed)

        if role is not None:
            fields.append('role=%s')
            params.append(role)
            is_staff_val = 1 if role == 'Administrator' else 0
            fields.append('is_staff=%s')
            params.append(is_staff_val)

        if full_name is not None:
            fields.append('full_name=%s')
            params.append(full_name)
        if phone is not None:
            fields.append('phone=%s')
            params.append(phone)
        if employee_id is not None:
            fields.append('employee_id=%s')
            params.append(employee_id)
        if region_id is not None:
            fields.append('region_id=%s')
            params.append(region_id)
        if area_id is not None:
            fields.append('area_id=%s')
            params.append(area_id)
        if branch_id is not None:
            fields.append('branch_id=%s')
            params.append(branch_id)
        if is_active is not None:
            fields.append('is_active=%s')
            params.append(1 if is_active else 0)

        if not fields:
            return Response({'message': 'No fields to update'}, status=status.HTTP_200_OK)

        update_sql = 'UPDATE auth_user SET ' + ', '.join(fields) + ' WHERE id=%s'
        params.append(target_id)

        try:
            with connection.cursor() as cursor:
                cursor.execute(update_sql, params)
                cursor.execute('''
                    SELECT id, username, password, email, phone, employee_id, role, 
                           region_id, area_id, branch_id, full_name, is_active, is_staff, 
                           last_login, is_superuser, date_joined
                    FROM auth_user WHERE id=%s
                ''', [target_id])
                cols = [c[0] for c in cursor.description] if cursor.description else []
                row = cursor.fetchone()
                user_data = dict(zip(cols, row)) if row else None

            return Response({'user': user_data, 'message': 'User updated successfully'}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)

class BLAgreementView(APIView):
    def post(self, request):
            """
            Simpan data BL Agreement ke tabel bl_agreement.
            """
            data = request.data
            contract_number = data.get('contract_number')
            branch_id = data.get('branch_id')
            director = data.get('director')
            bm_data = data.get('bm_data', {})
            contract_data = data.get('contract_data', {})
            collateral_data = data.get('collateral_data', {})
            header_fields = data.get('header_fields', {})

            # contract_number is optional now; allow saving without it

            try:
                with connection.cursor() as cursor:
                    # Determine actual columns in bl_agreement table
                    # SHOW COLUMNS returns: Field, Type, Null, Key, Default, Extra
                    cursor.execute("SHOW COLUMNS FROM bl_agreement")
                    cols_meta = cursor.fetchall()
                    cols_info = [row[0] for row in cols_meta]
                    # map lowercase column name -> actual column name to handle case differences
                    cols_lookup = {c.lower(): c for c in cols_info}

                    # Build a map of values to store, only for columns that actually exist
                    data_map = {}
                    # include contract_number only if provided
                    if contract_number:
                        data_map['contract_number'] = contract_number

                    # If frontend provided a created_by field (usernameDisplay), accept it
                    client_created_by = data.get('created_by')
                    if client_created_by and 'created_by' in cols_info:
                        data_map['created_by'] = client_created_by

                    # determine current user full name for created_by
                    # Resolve both username and full_name; prefer username for created_by
                    user_full_name = None
                    user_username = None
                    if getattr(request, 'user', None) and getattr(request.user, 'is_authenticated', False):
                        # request.user may be a minimal CustomUser (created by RawSQLJWTAuthentication)
                        user_full_name = getattr(request.user, 'full_name', None)
                        user_username = getattr(request.user, 'username', None)
                        if (not user_full_name or not user_username) and getattr(request.user, 'id', None):
                            try:
                                u = User.objects.filter(pk=request.user.id).first()
                                if u:
                                    if not user_full_name:
                                        user_full_name = getattr(u, 'full_name', None)
                                    if not user_username:
                                        user_username = getattr(u, 'username', None)
                            except Exception:
                                user_full_name = user_full_name or None
                                user_username = user_username or None
                    else:
                        # Try to decode JWT token from Authorization header as a fallback
                        auth_header = request.META.get('HTTP_AUTHORIZATION', '')
                        if auth_header and auth_header.startswith('Bearer '):
                            token = auth_header.split(' ', 1)[1].strip()
                            try:
                                payload = AccessToken(token)
                                user_id = payload.get('user_id') or payload.get('uid') or payload.get('id')
                                if user_id:
                                    try:
                                        u = User.objects.filter(pk=user_id).first()
                                        if u:
                                            user_full_name = getattr(u, 'full_name', None)
                                            user_username = getattr(u, 'username', None)
                                    except Exception:
                                        user_full_name = user_full_name or None
                                        user_username = user_username or None
                            except TokenError:
                                user_full_name = user_full_name or None
                                user_username = user_username or None
                    if not user_username:
                        # fallback to username from full_name or anonymous
                        user_username = user_username or (user_full_name and user_full_name.replace(' ', '').lower()) or 'anonymous'

                    now = timezone.now()

                    # Map simple top-level fields if corresponding columns exist
                    if branch_id is not None and 'branch_id' in cols_lookup:
                        data_map[cols_lookup['branch_id']] = branch_id
                    if director is not None:
                        # prefer column name 'name_of_director' if present, otherwise 'director'
                        if 'name_of_director' in cols_lookup:
                            data_map[cols_lookup['name_of_director']] = director
                        elif 'director' in cols_lookup:
                            data_map[cols_lookup['director']] = director

                    # Merge nested dictionaries (bm_data, branch_data, contract_data, collateral_data, header_fields)
                    # include branch_data so fields like `street_name` are processed when sent from frontend
                    branch_data = data.get('branch_data', {})
                    for src in (bm_data, branch_data, contract_data, collateral_data, header_fields):
                        if not isinstance(src, dict):
                            continue
                        for k, v in src.items():
                            key = str(k).lower()
                            # normalize some header field names
                            if key == 'name_of_director':
                                key = 'name_of_director'
                            # if column exists (case-insensitive), set using actual column name
                            if key in cols_lookup:
                                data_map[cols_lookup[key]] = v

                    # Sanitize date/datetime/timestamp fields provided by client.
                    # If a client supplies an unparseable value (e.g. 'B'), remove it
                    # so the NOT NULL default handling below can fill a safe value.
                    from datetime import datetime, date as _date
                    field_type_map = {row[0]: row[1].lower() for row in cols_meta}
                    for k in list(data_map.keys()):
                        ft = field_type_map.get(k, '')
                        if not any(t in ft for t in ('date', 'timestamp', 'datetime')):
                            continue
                        val = data_map.get(k)
                        # empty strings -> treat as None
                        if val is None or (isinstance(val, str) and val.strip() == ''):
                            data_map.pop(k, None)
                            continue
                        # already a date/datetime instance -> keep
                        if isinstance(val, (_date, datetime)):
                            continue
                        s = str(val).strip()
                        parsed = None
                        try:
                            try:
                                parsed = datetime.fromisoformat(s)
                            except Exception:
                                # Normalize spaced numeric dates like '15 04 2026' -> '15/04/2026'
                                import re
                                if re.match(r'^\s*\d{1,2}\s+\d{1,2}\s+\d{4}\s*$', s):
                                    s = re.sub(r'\s+', '/', s.strip())
                                # try several common formats (including '%d %m %Y')
                                for fmt in ('%Y-%m-%d', '%d-%m-%Y', '%d/%m/%Y', '%Y/%m/%d', '%d %m %Y', '%d %b %Y', '%d %B %Y'):
                                    try:
                                        parsed = datetime.strptime(s, fmt)
                                        break
                                    except Exception:
                                        continue
                            if parsed is None:
                                # couldn't parse -> drop the value so defaulting logic runs
                                data_map.pop(k, None)
                                continue
                            # For pure DATE columns, store a date object
                            if 'date' in ft and 'time' not in ft and 'datetime' not in ft:
                                data_map[k] = parsed.date()
                            else:
                                # For datetime/timestamp, make aware if naive
                                if parsed.tzinfo is None:
                                    parsed = timezone.make_aware(parsed)
                                data_map[k] = parsed
                        except Exception:
                            # On any error, remove the problematic key so default handling applies
                            data_map.pop(k, None)

                    # Prevent accidental override/insertion of primary key 'id'
                    if 'id' in data_map:
                        # remove incoming id so INSERT will use auto-increment
                        data_map.pop('id', None)

                    # Ensure certain fields have sensible defaults when not provided by frontend
                    # For numeric columns (int/decimal) use 0/0.0; otherwise fall back to '-'.
                    field_type_map = {row[0]: row[1].lower() for row in cols_meta}
                    for _f in ('admin_rate', 'tlo', 'life_insurance'):
                        if _f in cols_lookup and cols_lookup[_f] not in data_map:
                            ftype = field_type_map.get(_f, '')
                            if any(t in ftype for t in ('int', 'decimal', 'float', 'double')):
                                if 'decimal' in ftype or 'float' in ftype or 'double' in ftype:
                                    data_map[cols_lookup[_f]] = 0.0
                                else:
                                    data_map[cols_lookup[_f]] = 0
                            else:
                                data_map[cols_lookup[_f]] = '-'

                    # If some NOT NULL columns have no value provided, fill with safe defaults
                    # This prevents MySQL error 1364 when INSERT omits required columns.
                    # cols_meta rows: (Field, Type, Null, Key, Default, Extra)
                    for col_row in cols_meta:
                        field_name = col_row[0]
                        field_type = col_row[1].lower()
                        is_nullable = col_row[2]
                        default_val = col_row[4]
                        # Skip auto-managed or already-provided fields. Also skip created_by/created_at/update_at
                        if field_name in data_map:
                            continue
                        if field_name in ('id', 'created_by', 'created_at', 'update_at'):
                            continue

                        # If column is NOT NULL and has no default, provide a safe fallback
                        if is_nullable == 'NO' and default_val is None:
                            if any(t in field_type for t in ('int', 'decimal', 'float', 'double')):
                                data_map[field_name] = 0
                            elif any(t in field_type for t in ('date', 'timestamp', 'datetime')):
                                # use current timestamp for date/time types
                                data_map[field_name] = timezone.now()
                            else:
                                # default to '-' for textual/other types when frontend didn't include the field
                                data_map[field_name] = '-'

                    # Prepare columns and values for upsert
                    # Format date and numeric fields according to requirements
                    # NOTE: Formatting (date/number -> localized strings) is intentionally
                    # NOT applied here. Store raw values in DB and perform localization
                    # only when rendering/exporting (e.g., DOCX). This preserves numeric
                    # integrity (integers/decimals) and lets clients format as needed.
                    existing_check_sql = "SELECT contract_number FROM bl_agreement WHERE contract_number=%s"
                    exists = None
                    if contract_number:
                        cursor.execute(existing_check_sql, [contract_number])
                        exists = cursor.fetchone()

                    # If frontend explicitly requests edit-only or create-only behavior, enforce accordingly
                    edit_only = bool(data.get('edit_only'))
                    create_only = bool(data.get('create_only'))

                    if exists:
                        # If create_only requested but row exists, return error instead of updating
                        if create_only:
                            return Response({'error': 'Record already exists (create_only specified)'}, status=status.HTTP_400_BAD_REQUEST)
                        # UPDATE: add update_at timestamp if column exists
                        if 'update_at' in cols_info:
                            # do not overwrite created_by/created_at on update
                            data_map['update_at'] = now

                        # ensure we don't accidentally change created_by/created_at on update
                        data_map.pop('created_by', None)
                        data_map.pop('created_at', None)

                        # UPDATE
                        set_cols = []
                        params = []
                        for col, val in data_map.items():
                            if col == 'contract_number':
                                continue
                            set_cols.append(f"{col}=%s")
                            params.append(val)
                        if set_cols:
                            sql = f"UPDATE bl_agreement SET {', '.join(set_cols)} WHERE contract_number=%s"
                            params.append(contract_number)
                            cursor.execute(sql, params)
                    else:
                        # If edit_only requested but row doesn't exist, return error instead of inserting
                        if edit_only:
                            return Response({'error': 'Record not found for update (edit_only specified)'}, status=status.HTTP_400_BAD_REQUEST)
                        # If create_only is false, proceed to insert; if create_only true we already handled exists case above
                        # INSERT: set created_by (prefer username) and created_at if available
                        if 'created_by' in cols_info and user_username:
                            data_map['created_by'] = user_username
                        if 'created_at' in cols_info:
                            data_map['created_at'] = now

                        # INSERT
                        cols = []
                        placeholders = []
                        params = []
                        for col, val in data_map.items():
                            cols.append(col)
                            placeholders.append('%s')
                            params.append(val)
                        sql = f"INSERT INTO bl_agreement ({', '.join(cols)}) VALUES ({', '.join(placeholders)})"
                        cursor.execute(sql, params)
                return Response({'message': 'Data berhasil disimpan'}, status=status.HTTP_200_OK)
            except Exception as e:
                return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def get(self, request):
        contract_number = request.query_params.get('contract_number', '').strip()
        # Diagnostic: log incoming query params to help debug format handling / 404s
        try:
            logs_dir = os.path.join(settings.BASE_DIR, 'logs')
            os.makedirs(logs_dir, exist_ok=True)
            req_log = os.path.join(logs_dir, 'bl_agreement_docx_requests.log')
            with open(req_log, 'a', encoding='utf-8') as rf:
                rf.write(f"[{timezone.now().isoformat()}] query_params={dict(request.query_params)}\n")
        except Exception:
            pass

        try:
            with connection.cursor() as cursor:
                if not contract_number:
                    # Return list of agreements from bl_agreement table
                    # Select commonly used columns for listing
                    cursor.execute(
                        "SELECT agreement_date, contract_number, name_of_debtor, nik_number_of_debtor, collateral_type, created_by FROM bl_agreement ORDER BY COALESCE(agreement_date, created_at) DESC"
                    )
                    cols = [c[0] for c in cursor.description] if cursor.description else []
                    rows = cursor.fetchall()
                    items = [dict(zip(cols, r)) for r in rows]
                    return Response({'agreements': items}, status=status.HTTP_200_OK)

                # If contract_number provided, try to fetch from bl_agreement first
                cursor.execute(
                    "SELECT * FROM bl_agreement WHERE LOWER(contract_number) = LOWER(%s) LIMIT 1",
                    [contract_number]
                )
                cols = [col[0] for col in cursor.description] if cursor.description else []
                bl_row = cursor.fetchone()
                bl_data = dict(zip(cols, bl_row)) if bl_row else None

                # Attempt to get collateral data from bl_collateral
                cursor.execute(
                    "SELECT * FROM bl_collateral WHERE LOWER(contract_number) = LOWER(%s) LIMIT 1",
                    [contract_number]
                )
                collateral_columns = [col[0] for col in cursor.description] if cursor.description else []
                bl_collateral_row = cursor.fetchone()
                collateral_data = dict(zip(collateral_columns, bl_collateral_row)) if bl_collateral_row else None

                if bl_data:
                    # Enrich bl_data with related info if certain header fields are missing
                    try:
                        # Alias Name_of_director for frontend consistency
                        if 'name_of_director' in bl_data and 'Name_of_director' not in bl_data:
                            bl_data['Name_of_director'] = bl_data.get('name_of_director')

                        # If phone_number_of_lolc missing but director name present, try director table
                        if (not bl_data.get('phone_number_of_lolc')) and bl_data.get('name_of_director'):
                            cursor.execute("SELECT phone_number_of_lolc FROM director WHERE name_of_director=%s LIMIT 1", [bl_data.get('name_of_director')])
                            row = cursor.fetchone()
                            if row and row[0]:
                                bl_data['phone_number_of_lolc'] = row[0]

                        # If sp3 info missing, try bl_sp3 table for the latest entry
                        if (not bl_data.get('sp3_number') or not bl_data.get('sp3_date')):
                            cursor.execute("SELECT sp3_number, sp3_date FROM bl_sp3 WHERE LOWER(contract_number)=LOWER(%s) ORDER BY COALESCE(sp3_date, created_at) DESC LIMIT 1", [contract_number])
                            sp3row = cursor.fetchone()
                            if sp3row:
                                if not bl_data.get('sp3_number') and sp3row[0]:
                                    bl_data['sp3_number'] = sp3row[0]
                                if not bl_data.get('sp3_date') and sp3row[1]:
                                    bl_data['sp3_date'] = sp3row[1]
                    except Exception:
                        # Non-fatal enrichment failure; continue returning base bl_data
                        pass

                    return Response({'debtor': bl_data, 'collateral': collateral_data}, status=status.HTTP_200_OK)

                # Fallback to legacy `contract` table if bl_agreement not present
                cursor.execute(
                    "SELECT * FROM contract WHERE LOWER(contract_number) = LOWER(%s) LIMIT 1",
                    [contract_number]
                )
                columns = [col[0] for col in cursor.description] if cursor.description else []
                contract_row = cursor.fetchone()
                debtor_data = dict(zip(columns, contract_row)) if contract_row else None

                # If neither table has the contract, return 404
                if not debtor_data and not collateral_data:
                    return Response({
                        'debtor': None,
                        'collateral': None,
                        'message': 'Data tidak ditemukan untuk nomor kontrak ini'
                    }, status=status.HTTP_404_NOT_FOUND)

                return Response({'debtor': debtor_data, 'collateral': collateral_data}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': f'Error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


        class UVAgreementView(APIView):
            """
            Mirrors BLAgreementView behavior but operates on uv_agreement and uv_collateral tables.
            This keeps BL endpoints untouched while providing the same save/list/get semantics
            for UV agreements.
            """
            permission_classes = [IsAuthenticated]

            def post(self, request):
                data = request.data
                contract_number = data.get('contract_number')
                branch_id = data.get('branch_id')
                director = data.get('director')
                bm_data = data.get('bm_data', {})
                contract_data = data.get('contract_data', {})
                collateral_data = data.get('collateral_data', {})
                header_fields = data.get('header_fields', {})

                try:
                    with connection.cursor() as cursor:
                        cursor.execute("SHOW COLUMNS FROM uv_agreement")
                        cols_meta = cursor.fetchall()
                        cols_info = [row[0] for row in cols_meta]
                        cols_lookup = {c.lower(): c for c in cols_info}

                        data_map = {}
                        if contract_number:
                            data_map['contract_number'] = contract_number

                        client_created_by = data.get('created_by')
                        if client_created_by and 'created_by' in cols_info:
                            data_map['created_by'] = client_created_by

                        user_full_name = None
                        user_username = None
                        if getattr(request, 'user', None) and getattr(request.user, 'is_authenticated', False):
                            user_full_name = getattr(request.user, 'full_name', None)
                            user_username = getattr(request.user, 'username', None)
                            if (not user_full_name or not user_username) and getattr(request.user, 'id', None):
                                try:
                                    u = User.objects.filter(pk=request.user.id).first()
                                    if u:
                                        user_full_name = user_full_name or getattr(u, 'full_name', None)
                                        user_username = user_username or getattr(u, 'username', None)
                                except Exception:
                                    pass
                        else:
                            auth_header = request.META.get('HTTP_AUTHORIZATION', '')
                            if auth_header and auth_header.startswith('Bearer '):
                                token = auth_header.split(' ', 1)[1].strip()
                                try:
                                    payload = AccessToken(token)
                                    user_id = payload.get('user_id') or payload.get('uid') or payload.get('id')
                                    if user_id:
                                        try:
                                            u = User.objects.filter(pk=user_id).first()
                                            if u:
                                                user_full_name = user_full_name or getattr(u, 'full_name', None)
                                                user_username = user_username or getattr(u, 'username', None)
                                        except Exception:
                                            pass
                                except TokenError:
                                    pass

                        user_username = user_username or (user_full_name and user_full_name.replace(' ', '').lower()) or 'anonymous'
                        now = timezone.now()

                        if branch_id is not None and 'branch_id' in cols_lookup:
                            data_map[cols_lookup['branch_id']] = branch_id
                        if director is not None:
                            if 'name_of_director' in cols_lookup:
                                data_map[cols_lookup['name_of_director']] = director
                            elif 'director' in cols_lookup:
                                data_map[cols_lookup['director']] = director

                        branch_data = data.get('branch_data', {})
                        for src in (bm_data, branch_data, contract_data, collateral_data, header_fields):
                            if not isinstance(src, dict):
                                continue
                            for k, v in src.items():
                                key = str(k).lower()
                                if key == 'name_of_director':
                                    key = 'name_of_director'
                                if key in cols_lookup:
                                    data_map[cols_lookup[key]] = v

                        from datetime import datetime, date as _date
                        field_type_map = {row[0]: row[1].lower() for row in cols_meta}
                        for k in list(data_map.keys()):
                            ft = field_type_map.get(k, '')
                            if not any(t in ft for t in ('date', 'timestamp', 'datetime')):
                                continue
                            val = data_map.get(k)
                            if val is None or (isinstance(val, str) and val.strip() == ''):
                                data_map.pop(k, None)
                                continue
                            if isinstance(val, (_date, datetime)):
                                continue
                            s = str(val).strip()
                            parsed = None
                            try:
                                try:
                                    parsed = datetime.fromisoformat(s)
                                except Exception:
                                    import re
                                    if re.match(r'^\s*\d{1,2}\s+\d{1,2}\s+\d{4}\s*$', s):
                                        s = re.sub(r'\s+', '/', s.strip())
                                    for fmt in ('%Y-%m-%d', '%d-%m-%Y', '%d/%m/%Y', '%Y/%m/%d', '%d %m %Y', '%d %b %Y', '%d %B %Y'):
                                        try:
                                            parsed = datetime.strptime(s, fmt)
                                            break
                                        except Exception:
                                            continue
                                if parsed is None:
                                    data_map.pop(k, None)
                                    continue
                                if 'date' in ft and 'time' not in ft and 'datetime' not in ft:
                                    data_map[k] = parsed.date()
                                else:
                                    if parsed.tzinfo is None:
                                        parsed = timezone.make_aware(parsed)
                                    data_map[k] = parsed
                            except Exception:
                                data_map.pop(k, None)

                        if 'id' in data_map:
                            data_map.pop('id', None)

                        field_type_map = {row[0]: row[1].lower() for row in cols_meta}
                        for _f in ('admin_rate', 'tlo', 'life_insurance'):
                            if _f in cols_lookup and cols_lookup[_f] not in data_map:
                                ftype = field_type_map.get(_f, '')
                                if any(t in ftype for t in ('int', 'decimal', 'float', 'double')):
                                    if 'decimal' in ftype or 'float' in ftype or 'double' in ftype:
                                        data_map[cols_lookup[_f]] = 0.0
                                    else:
                                        data_map[cols_lookup[_f]] = 0
                                else:
                                    data_map[cols_lookup[_f]] = '-'

                        for col_row in cols_meta:
                            field_name = col_row[0]
                            field_type = col_row[1].lower()
                            is_nullable = col_row[2]
                            default_val = col_row[4]
                            if field_name in data_map:
                                continue
                            if field_name in ('id', 'created_by', 'created_at', 'update_at'):
                                continue
                            if is_nullable == 'NO' and default_val is None:
                                if any(t in field_type for t in ('int', 'decimal', 'float', 'double')):
                                    data_map[field_name] = 0
                                elif any(t in field_type for t in ('date', 'timestamp', 'datetime')):
                                    data_map[field_name] = timezone.now()
                                else:
                                    data_map[field_name] = '-'

                        existing_check_sql = "SELECT contract_number FROM uv_agreement WHERE contract_number=%s"
                        exists = None
                        if contract_number:
                            cursor.execute(existing_check_sql, [contract_number])
                            exists = cursor.fetchone()

                        edit_only = bool(data.get('edit_only'))
                        create_only = bool(data.get('create_only'))

                        if exists:
                            if create_only:
                                return Response({'error': 'Record already exists (create_only specified)'}, status=status.HTTP_400_BAD_REQUEST)
                            if 'update_at' in cols_info:
                                data_map['update_at'] = now
                            data_map.pop('created_by', None)
                            data_map.pop('created_at', None)
                            set_cols = []
                            params = []
                            for col, val in data_map.items():
                                if col == 'contract_number':
                                    continue
                                set_cols.append(f"{col}=%s")
                                params.append(val)
                            if set_cols:
                                sql = f"UPDATE uv_agreement SET {', '.join(set_cols)} WHERE contract_number=%s"
                                params.append(contract_number)
                                cursor.execute(sql, params)
                        else:
                            if edit_only:
                                return Response({'error': 'Record not found for update (edit_only specified)'}, status=status.HTTP_400_BAD_REQUEST)
                            if 'created_by' in cols_info and user_username:
                                data_map['created_by'] = user_username
                            if 'created_at' in cols_info:
                                data_map['created_at'] = now
                            cols = []
                            placeholders = []
                            params = []
                            for col, val in data_map.items():
                                cols.append(col)
                                placeholders.append('%s')
                                params.append(val)
                            sql = f"INSERT INTO uv_agreement ({', '.join(cols)}) VALUES ({', '.join(placeholders)})"
                            cursor.execute(sql, params)

                    return Response({'message': 'Data UV berhasil disimpan'}, status=status.HTTP_200_OK)
                except Exception as e:
                    return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

            def get(self, request):
                contract_number = request.query_params.get('contract_number', '').strip()
                try:
                    with connection.cursor() as cursor:
                        if not contract_number:
                            cursor.execute(
                                "SELECT agreement_date, contract_number, name_of_debtor, nik_number_of_debtor, collateral_type, created_by FROM uv_agreement ORDER BY COALESCE(agreement_date, created_at) DESC"
                            )
                            cols = [c[0] for c in cursor.description] if cursor.description else []
                            rows = cursor.fetchall()
                            items = [dict(zip(cols, r)) for r in rows]
                            return Response({'agreements': items}, status=status.HTTP_200_OK)

                        cursor.execute(
                            "SELECT * FROM uv_agreement WHERE LOWER(contract_number) = LOWER(%s) LIMIT 1",
                            [contract_number]
                        )
                        cols = [col[0] for col in cursor.description] if cursor.description else []
                        uv_row = cursor.fetchone()
                        uv_data = dict(zip(cols, uv_row)) if uv_row else None

                        cursor.execute(
                            "SELECT * FROM uv_collateral WHERE LOWER(contract_number) = LOWER(%s) LIMIT 1",
                            [contract_number]
                        )
                        collateral_columns = [col[0] for col in cursor.description] if cursor.description else []
                        uv_collateral_row = cursor.fetchone()
                        collateral_data = dict(zip(collateral_columns, uv_collateral_row)) if uv_collateral_row else None

                        if uv_data:
                            try:
                                if 'name_of_director' in uv_data and 'Name_of_director' not in uv_data:
                                    uv_data['Name_of_director'] = uv_data.get('name_of_director')
                            except Exception:
                                pass
                            return Response({'debtor': uv_data, 'collateral': collateral_data}, status=status.HTTP_200_OK)

                        cursor.execute(
                            "SELECT * FROM contract WHERE LOWER(contract_number) = LOWER(%s) LIMIT 1",
                            [contract_number]
                        )
                        columns = [col[0] for col in cursor.description] if cursor.description else []
                        contract_row = cursor.fetchone()
                        debtor_data = dict(zip(columns, contract_row)) if contract_row else None

                        if not debtor_data and not collateral_data:
                            return Response({'debtor': None, 'collateral': None, 'message': 'Data tidak ditemukan untuk nomor kontrak ini'}, status=status.HTTP_404_NOT_FOUND)

                        return Response({'debtor': debtor_data, 'collateral': collateral_data}, status=status.HTTP_200_OK)
                except Exception as e:
                    return Response({'error': f'Error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


        class UVCollateralCreateView(APIView):
            """Create or update UV collateral rows (mirrors BL collateral handler semantics)."""
            permission_classes = [IsAuthenticated]

            def post(self, request):
                data = request.data
                contract_number = data.get('contract_number')
                collateral = data.get('collateral', {})
                if not contract_number:
                    return Response({'error': 'contract_number is required'}, status=status.HTTP_400_BAD_REQUEST)

                try:
                    with connection.cursor() as cursor:
                        cursor.execute("SHOW COLUMNS FROM uv_collateral")
                        cols_meta = cursor.fetchall()
                        cols_info = [r[0] for r in cols_meta]
                        cols_lookup = {c.lower(): c for c in cols_info}

                        data_map = {'contract_number': contract_number}
                        if isinstance(collateral, dict):
                            for k, v in collateral.items():
                                key = str(k).lower()
                                if key in cols_lookup:
                                    data_map[cols_lookup[key]] = v

                        for col_row in cols_meta:
                            field_name = col_row[0]
                            field_type = col_row[1].lower()
                            is_nullable = col_row[2]
                            default_val = col_row[4]
                            if field_name in data_map:
                                continue
                            if field_name in ('id', 'created_by', 'created_at', 'update_at'):
                                continue
                            if is_nullable == 'NO' and default_val is None:
                                if any(t in field_type for t in ('int', 'decimal', 'float', 'double')):
                                    data_map[field_name] = 0
                                elif any(t in field_type for t in ('date', 'timestamp', 'datetime')):
                                    data_map[field_name] = timezone.now()
                                else:
                                    data_map[field_name] = '-'

                        cursor.execute("SELECT contract_number FROM uv_collateral WHERE contract_number=%s LIMIT 1", [contract_number])
                        exists = cursor.fetchone()
                        if exists:
                            set_cols = []
                            params = []
                            for col, val in data_map.items():
                                if col == 'contract_number':
                                    continue
                                set_cols.append(f"{col}=%s")
                                params.append(val)
                            if set_cols:
                                sql = f"UPDATE uv_collateral SET {', '.join(set_cols)} WHERE contract_number=%s"
                                params.append(contract_number)
                                cursor.execute(sql, params)
                        else:
                            cols = []
                            placeholders = []
                            params = []
                            for col, val in data_map.items():
                                cols.append(col)
                                placeholders.append('%s')
                                params.append(val)
                            sql = f"INSERT INTO uv_collateral ({', '.join(cols)}) VALUES ({', '.join(placeholders)})"
                            cursor.execute(sql, params)

                    return Response({'message': 'UV collateral saved'}, status=status.HTTP_200_OK)
                except Exception as e:
                    return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class BLAgreementContractListView(APIView):
    """
    API endpoint untuk mengambil daftar contract numbers dari tabel bl_agreement dan bl_collateral.
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            with connection.cursor() as cursor:
                # Get unique contract numbers dari `contract` table
                cursor.execute(
                    "SELECT DISTINCT contract_number FROM contract ORDER BY contract_number"
                )
                bl_contracts = [row[0] for row in cursor.fetchall()]
                
                # Get unique contract numbers dari bl_collateral
                cursor.execute(
                    "SELECT DISTINCT contract_number FROM bl_collateral ORDER BY contract_number"
                )
                bl_collateral_contracts = [row[0] for row in cursor.fetchall()]
                
                # Merge dan unique
                all_contracts = sorted(list(set(bl_contracts + bl_collateral_contracts)))
                
                return Response({
                    'contracts': all_contracts
                }, status=status.HTTP_200_OK)
        
        except Exception as e:
            return Response(
                {'error': f'Error: {str(e)}'}, 
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class ContractCreateView(APIView):
    """
    API endpoint to create a row in the legacy `contract` table.
    Frontend expects POST to `/api/contracts/` with contract fields (excluding *_in_word/_by_word).
    This endpoint will insert only columns that exist in the `contract` table and will
    populate `created_by`, `created_at`, `updated_at` when available.
    """
    permission_classes = [IsAuthenticated]

    def post(self, request):
        data = request.data or {}
        try:
            with connection.cursor() as cursor:
                # discover contract table columns (map lowercase -> actual name)
                cursor.execute("SHOW COLUMNS FROM contract")
                cols_meta = cursor.fetchall()
                cols_info = [row[0] for row in cols_meta]
                cols_lookup = {c.lower(): c for c in cols_info}

                # build data map only for columns that exist (use actual column names)
                data_map = {}
                for k, v in data.items():
                    key = str(k).lower()
                    # skip helper fields
                    if key.endswith('_in_word') or key.endswith('_by_word'):
                        continue
                    if key in cols_lookup:
                        data_map[cols_lookup[key]] = v

                # Remove any client-supplied timestamp fields (may be ISO strings with Z)
                # and set server-side timestamps in DB-friendly format.
                if 'created_at' in data_map:
                    data_map.pop('created_at', None)
                if 'updated_at' in data_map:
                    data_map.pop('updated_at', None)

                # set audit fields if available
                now = timezone.now()
                auth_user = getattr(request, 'user', None)
                username = None
                if auth_user and getattr(auth_user, 'is_authenticated', False):
                    username = getattr(auth_user, 'username', None) or getattr(auth_user, 'full_name', None)
                else:
                    # try decode token fallback
                    auth_header = request.META.get('HTTP_AUTHORIZATION', '')
                    if auth_header and auth_header.startswith('Bearer '):
                        try:
                            payload = AccessToken(auth_header.split(' ',1)[1].strip())
                            user_id = payload.get('user_id') or payload.get('uid') or payload.get('id')
                            if user_id:
                                u = User.objects.filter(pk=user_id).first()
                                if u:
                                    username = getattr(u, 'username', None) or getattr(u, 'full_name', None)
                        except Exception:
                            username = None

                if 'created_by' in cols_lookup and cols_lookup['created_by'] not in data_map:
                    data_map[cols_lookup['created_by']] = username or ''
                # Always set timestamps server-side to avoid timezone/format issues from client
                if 'created_at' in cols_lookup:
                    data_map[cols_lookup['created_at']] = now
                if 'updated_at' in cols_lookup:
                    data_map[cols_lookup['updated_at']] = now

                # Ensure admin_rate, tlo, life_insurance have sensible defaults when not provided
                # Use numeric 0 for numeric columns (int/decimal/float), otherwise '-' for text
                field_type_map = {row[0].lower(): row[1].lower() for row in cols_meta}
                for _f in ('admin_rate', 'tlo', 'life_insurance'):
                    if _f in cols_lookup and cols_lookup[_f] not in data_map:
                        ftype = field_type_map.get(_f, '')
                        if any(t in ftype for t in ('int', 'decimal', 'float', 'double')):
                            # decimal -> use 0.0, integers -> 0
                            if 'decimal' in ftype or 'float' in ftype or 'double' in ftype:
                                data_map[cols_lookup[_f]] = 0.0
                            else:
                                data_map[cols_lookup[_f]] = 0
                        else:
                            data_map[cols_lookup[_f]] = '-'

                # If some NOT NULL columns have no value provided, fill with safe defaults
                # This prevents MySQL error 1364 when INSERT omits required columns.
                # cols_meta rows: (Field, Type, Null, Key, Default, Extra)
                for col_row in cols_meta:
                    field_name = col_row[0]
                    field_type = col_row[1].lower()
                    is_nullable = col_row[2]
                    default_val = col_row[4]
                    # Skip auto-managed or already-provided fields. Also skip created_by/created_at/updated_at
                    if field_name in data_map:
                        continue
                    if field_name in ('id', 'created_by', 'created_at', 'updated_at'):
                        continue

                    if is_nullable == 'NO' and default_val is None:
                        if any(t in field_type for t in ('int', 'decimal', 'float', 'double')):
                            # decimal -> 0.0, integers -> 0
                            if 'decimal' in field_type or 'float' in field_type or 'double' in field_type:
                                data_map[field_name] = 0.0
                            else:
                                data_map[field_name] = 0
                        elif any(t in field_type for t in ('date', 'timestamp', 'datetime')):
                            data_map[field_name] = timezone.now()
                        else:
                            data_map[field_name] = '-'

                # Prevent inserting primary key id if provided
                if 'id' in data_map:
                    data_map.pop('id', None)

                if not data_map:
                    return Response({'error': 'No valid contract fields provided'}, status=status.HTTP_400_BAD_REQUEST)

                cols = []
                placeholders = []
                params = []
                for col, val in data_map.items():
                    cols.append(col)
                    placeholders.append('%s')
                    params.append(val)

                sql = f"INSERT INTO contract ({', '.join(cols)}) VALUES ({', '.join(placeholders)})"
                cursor.execute(sql, params)

            return Response({'message': 'Contract saved'}, status=status.HTTP_200_OK)
        except Exception as e:
            logger.exception('Failed to save contract')
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def get(self, request):
        """
        Allow frontend to lookup a contract row by contract_number using GET /api/contracts/?contract_number=...
        Returns JSON: { "contract": { ... } }
        """
        contract_number = request.GET.get('contract_number') or request.query_params.get('contract_number')
        if not contract_number:
            return Response({'error': 'contract_number query parameter required'}, status=status.HTTP_400_BAD_REQUEST)
        try:
            with connection.cursor() as cursor:
                cursor.execute("SHOW COLUMNS FROM contract")
                cols_meta = cursor.fetchall()
                cols_info = [row[0] for row in cols_meta]
                # Build SELECT with explicit columns to preserve order
                sql = f"SELECT {', '.join(cols_info)} FROM contract WHERE contract_number = %s LIMIT 1"
                cursor.execute(sql, [contract_number])
                row = cursor.fetchone()
                if not row:
                    return Response({'error': 'Not found'}, status=status.HTTP_404_NOT_FOUND)
                row_dict = {cols_info[i]: row[i] for i in range(len(cols_info))}
                return Response({'contract': row_dict}, status=status.HTTP_200_OK)
        except Exception as e:
            logger.exception('Contract lookup failed')
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class ContractLookupView(APIView):
    """
    Dedicated lookup endpoint returning a contract row for a given contract_number.
    This is used by frontend create-modal lookups when GET on /api/contracts/ is not desired.
    """
    permission_classes = [IsAuthenticated]

    def get(self, request):
        contract_number = request.query_params.get('contract_number')
        if not contract_number:
            return Response({'error': 'contract_number required'}, status=status.HTTP_400_BAD_REQUEST)
        try:
            with connection.cursor() as cursor:
                cursor.execute("SHOW COLUMNS FROM contract")
                cols_meta = cursor.fetchall()
                cols_info = [row[0] for row in cols_meta]
                sql = f"SELECT {', '.join(cols_info)} FROM contract WHERE LOWER(contract_number)=LOWER(%s) LIMIT 1"
                cursor.execute(sql, [contract_number])
                row = cursor.fetchone()
                if not row:
                    return Response({'error': 'Not found'}, status=status.HTTP_404_NOT_FOUND)
                row_dict = {cols_info[i]: row[i] for i in range(len(cols_info))}
                return Response({'contract': row_dict}, status=status.HTTP_200_OK)
        except Exception as e:
            logger.exception('ContractLookup failed')
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class BLCollateralCreateView(APIView):
    """
    Endpoint to insert a bl_collateral row. Frontend will POST contract_number and collateral fields.
    """
    permission_classes = [IsAuthenticated]

    def post(self, request):
        data = request.data or {}
        try:
            with connection.cursor() as cursor:
                cursor.execute("SHOW COLUMNS FROM bl_collateral")
                cols_meta = cursor.fetchall()
                cols_info = [r[0] for r in cols_meta]

                data_map = {}
                for k, v in data.items():
                    key = str(k).lower()
                    if key.endswith('_in_word') or key.endswith('_by_word'):
                        continue
                    if key in cols_info:
                        data_map[key] = v

                # server-side timestamps and audit
                now = timezone.now()
                auth_user = getattr(request, 'user', None)
                username = None
                if auth_user and getattr(auth_user, 'is_authenticated', False):
                    username = getattr(auth_user, 'username', None) or getattr(auth_user, 'full_name', None)
                else:
                    auth_header = request.META.get('HTTP_AUTHORIZATION', '')
                    if auth_header and auth_header.startswith('Bearer '):
                        try:
                            payload = AccessToken(auth_header.split(' ',1)[1].strip())
                            user_id = payload.get('user_id') or payload.get('uid') or payload.get('id')
                            if user_id:
                                u = User.objects.filter(pk=user_id).first()
                                if u:
                                    username = getattr(u, 'username', None) or getattr(u, 'full_name', None)
                        except Exception:
                            username = None

                if 'created_by' in cols_info and 'created_by' not in data_map:
                    data_map['created_by'] = username or ''
                if 'created_at' in cols_info:
                    data_map['created_at'] = now
                if 'update_at' in cols_info:
                    data_map['update_at'] = now

                if 'id' in data_map:
                    data_map.pop('id', None)

                if not data_map:
                    return Response({'error': 'No valid collateral fields provided'}, status=status.HTTP_400_BAD_REQUEST)

                cols = []
                placeholders = []
                params = []
                for col, val in data_map.items():
                    cols.append(col)
                    placeholders.append('%s')
                    params.append(val)

                sql = f"INSERT INTO bl_collateral ({', '.join(cols)}) VALUES ({', '.join(placeholders)})"
                cursor.execute(sql, params)

            return Response({'message': 'Collateral saved'}, status=status.HTTP_200_OK)
        except Exception as e:
            logger.exception('Failed to save bl_collateral')
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class BLSP3View(APIView):
    """Create/update and lookup BL SP3 rows.
    POST: insert or update a bl_sp3 row keyed by contract_number.
    GET: return latest bl_sp3 row for given contract_number.
    """
    permission_classes = [IsAuthenticated]

    def post(self, request):
        data = request.data or {}
        contract_number = data.get('contract_number') or data.get('contractNumber')
        if not contract_number:
            return Response({'error': 'contract_number is required'}, status=status.HTTP_400_BAD_REQUEST)
        try:
            with connection.cursor() as cursor:
                cursor.execute("SHOW COLUMNS FROM bl_sp3")
                cols_meta = cursor.fetchall()
                cols_info = [r[0] for r in cols_meta]
                cols_lookup = {c.lower(): c for c in cols_info}

                data_map = {'contract_number': contract_number}
                # Accept nested payload pieces
                for k, v in data.items():
                    key = str(k).lower()
                    if key in cols_lookup:
                        data_map[cols_lookup[key]] = v

                # also map header_fields, contract_data, debtor, collateral_data, bm_data, branch_data
                for section in ('header_fields', 'contract_data', 'debtor', 'collateral_data', 'bm_data', 'branch_data'):
                    sec = data.get(section) or {}
                    if isinstance(sec, dict):
                        for k, v in sec.items():
                            lk = str(k).lower()
                            if lk in cols_lookup:
                                data_map[cols_lookup[lk]] = v

                # Fill defaults for non-nullable columns
                for col_row in cols_meta:
                    field_name = col_row[0]
                    field_type = (col_row[1] or '').lower()
                    is_nullable = col_row[2]
                    default_val = col_row[4]
                    if field_name in data_map:
                        continue
                    if field_name in ('id', 'created_by', 'created_at', 'update_at'):
                        continue
                    if is_nullable == 'NO' and default_val is None:
                        if any(t in field_type for t in ('int', 'decimal', 'float', 'double')):
                            data_map[field_name] = 0
                        elif any(t in field_type for t in ('date', 'timestamp', 'datetime')):
                            data_map[field_name] = timezone.now()
                        else:
                            data_map[field_name] = ''

                # Always insert a new row for BL SP3 (allow duplicate contract_number)
                cols = []
                placeholders = []
                params = []
                for col, val in data_map.items():
                    cols.append(col)
                    placeholders.append('%s')
                    params.append(val)
                sql = f"INSERT INTO bl_sp3 ({', '.join(cols)}) VALUES ({', '.join(placeholders)})"
                cursor.execute(sql, params)

            return Response({'message': 'BL SP3 saved'}, status=status.HTTP_200_OK)
        except Exception as e:
            logger.exception('Failed to save bl_sp3')
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    def get(self, request):
        contract_number = request.query_params.get('contract_number') or request.GET.get('contract_number')
        try:
            with connection.cursor() as cursor:
                cursor.execute("SHOW COLUMNS FROM bl_sp3")
                cols_meta = cursor.fetchall()
                cols_info = [row[0] for row in cols_meta]

                if contract_number:
                    # return latest row for this contract
                    sql = f"SELECT {', '.join(cols_info)} FROM bl_sp3 WHERE LOWER(contract_number)=LOWER(%s) ORDER BY COALESCE(sp3_date, created_at) DESC LIMIT 1"
                    cursor.execute(sql, [contract_number])
                    row = cursor.fetchone()
                    if not row:
                        return Response({'error': 'Not found'}, status=status.HTTP_404_NOT_FOUND)
                    row_dict = {cols_info[i]: row[i] for i in range(len(cols_info))}
                    return Response({'sp3': row_dict}, status=status.HTTP_200_OK)
                else:
                    # return list of recent sp3 rows
                    sql = f"SELECT {', '.join(cols_info)} FROM bl_sp3 ORDER BY COALESCE(sp3_date, created_at) DESC"
                    cursor.execute(sql)
                    rows = cursor.fetchall()
                    results = []
                    for r in rows:
                        results.append({cols_info[i]: r[i] for i in range(len(cols_info))})
                    return Response({'sp3s': results}, status=status.HTTP_200_OK)
        except Exception as e:
            logger.exception('BLSP3 lookup failed')
            return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


@csrf_exempt
def bl_sp3_public_create(request):
    """Public endpoint to create BL SP3 rows without auth (always INSERT).
    Expects JSON body similar to BLSP3View POST.
    """
    if request.method != 'POST':
        return JsonResponse({'error': 'Method not allowed'}, status=405)
    try:
        import json
        body = request.body.decode('utf-8') or '{}'
        data = json.loads(body)
    except Exception:
        data = {}
    contract_number = data.get('contract_number') or data.get('contractNumber')
    if not contract_number:
        return JsonResponse({'error': 'contract_number is required'}, status=400)
    try:
        with connection.cursor() as cursor:
            cursor.execute("SHOW COLUMNS FROM bl_sp3")
            cols_meta = cursor.fetchall()
            cols_info = [r[0] for r in cols_meta]
            cols_lookup = {c.lower(): c for c in cols_info}

            data_map = {'contract_number': contract_number}
            for k, v in data.items():
                key = str(k).lower()
                if key in cols_lookup:
                    data_map[cols_lookup[key]] = v

            for section in ('header_fields', 'contract_data', 'debtor', 'collateral_data', 'bm_data', 'branch_data'):
                sec = data.get(section) or {}
                if isinstance(sec, dict):
                    for k, v in sec.items():
                        lk = str(k).lower()
                        if lk in cols_lookup:
                            data_map[cols_lookup[lk]] = v

            # Fill minimal defaults for some non-nullable fields if absent
            for col_row in cols_meta:
                field_name = col_row[0]
                is_nullable = col_row[2]
                default_val = col_row[4]
                extra = (col_row[5] or '')
                if field_name in data_map:
                    continue
                # Skip known auto-increment PKs and internal timestamp/creator fields
                if field_name in ('id', 'created_by', 'created_at', 'update_at') or 'auto_increment' in extra.lower():
                    continue
                if is_nullable == 'NO' and default_val is None:
                    data_map[field_name] = ''

            cols = []
            placeholders = []
            params = []
            for col, val in data_map.items():
                cols.append(col)
                placeholders.append('%s')
                params.append(val)
            sql = f"INSERT INTO bl_sp3 ({', '.join(cols)}) VALUES ({', '.join(placeholders)})"
            cursor.execute(sql, params)

        return JsonResponse({'message': 'BL SP3 created'}, status=200)
    except Exception as e:
        import logging
        logging.exception('Public BL SP3 insert failed')
        return JsonResponse({'error': str(e)}, status=500)


class WhoAmIView(APIView):
    """Debug endpoint: return resolved full_name for the current request's token/user."""
    permission_classes = []

    def get(self, request):
        # Try request.user first
        full_name = None
        if getattr(request, 'user', None) and getattr(request.user, 'is_authenticated', False):
            full_name = getattr(request.user, 'full_name', None) or getattr(request.user, 'username', None)
            if (not full_name) and getattr(request.user, 'id', None):
                u = User.objects.filter(pk=request.user.id).first()
                if u:
                    full_name = getattr(u, 'full_name', None) or getattr(u, 'username', None)

        # Fallback: decode token
        if not full_name:
            auth_header = request.META.get('HTTP_AUTHORIZATION', '')
            if auth_header and auth_header.startswith('Bearer '):
                token = auth_header.split(' ', 1)[1].strip()
                try:
                    payload = AccessToken(token)
                    user_id = payload.get('user_id') or payload.get('uid') or payload.get('id')
                    if user_id:
                        u = User.objects.filter(pk=user_id).first()
                        if u:
                            full_name = getattr(u, 'full_name', None) or getattr(u, 'username', None)
                except Exception:
                    full_name = None

        # Also return username when available for frontend display
        username = None
        if getattr(request, 'user', None) and getattr(request.user, 'is_authenticated', False):
            username = getattr(request.user, 'username', None)
            if (not username) and getattr(request.user, 'id', None):
                u = User.objects.filter(pk=request.user.id).first()
                if u:
                    username = getattr(u, 'username', None)
        if not username:
            # try token payload
            auth_header = request.META.get('HTTP_AUTHORIZATION', '')
            if auth_header and auth_header.startswith('Bearer '):
                try:
                    payload = AccessToken(auth_header.split(' ', 1)[1].strip())
                    user_id = payload.get('user_id') or payload.get('uid') or payload.get('id')
                    if user_id:
                        u = User.objects.filter(pk=user_id).first()
                        if u:
                            username = getattr(u, 'username', None)
                except Exception:
                    username = None

        return Response({'full_name': full_name or 'anonymous', 'username': username or 'anonymous'}, status=status.HTTP_200_OK)


class BranchListView(APIView):
    """Return distinct branch cities (city_of_bm) from branch manager table."""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            with connection.cursor() as cursor:
                cursor.execute("SELECT DISTINCT city_of_bm FROM branch_manager ORDER BY city_of_bm")
                rows = [row[0] for row in cursor.fetchall()]
                return Response({'branches': rows}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': f'Error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class RegionListView(APIView):
    """Return list of regions with id and name."""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        try:
            with connection.cursor() as cursor:
                cursor.execute("SELECT id, region_name FROM regions WHERE is_active=1 ORDER BY region_name")
                cols = ['id', 'name']
                rows = [dict(zip(cols, row)) for row in cursor.fetchall()]
                return Response({'regions': rows}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': f'Error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class AreaListView(APIView):
    """Return list of areas with id, name, and region_id."""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        region_id = request.query_params.get('region_id')
        try:
            with connection.cursor() as cursor:
                if region_id:
                    cursor.execute("SELECT id, name, region_id FROM areas WHERE region_id=%s AND is_active=1 ORDER BY name", [region_id])
                else:
                    cursor.execute("SELECT id, name, region_id FROM areas WHERE is_active=1 ORDER BY name")
                cols = ['id', 'name', 'region_id']
                rows = [dict(zip(cols, row)) for row in cursor.fetchall()]
                return Response({'areas': rows}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': f'Error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class BranchListView(APIView):
    """Return list of branches with id, name, and area_id.

    This endpoint is intentionally left without authentication to avoid
    user-model related DB queries (some environments have a custom
    `auth_user` table missing standard fields). Frontend requires branch
    data to populate filters, so keep this public.
    """
    permission_classes = []

    def get(self, request):
        area_id = request.query_params.get('area_id')
        try:
            with connection.cursor() as cursor:
                # Use dynamic selection of branch and BM columns (b.* and bm.*)
                # This avoids referencing columns that may not exist in some databases
                if area_id:
                    cursor.execute(
                        "SELECT b.*, bm.* FROM branches b LEFT JOIN branch_manager bm ON b.bm_id = bm.bm_id WHERE b.area_id=%s AND b.is_active=1 ORDER BY b.name",
                        [area_id]
                    )
                else:
                    cursor.execute(
                        "SELECT b.*, bm.* FROM branches b LEFT JOIN branch_manager bm ON b.bm_id = bm.bm_id WHERE b.is_active=1 ORDER BY b.name"
                    )
                cols = [c[0] for c in cursor.description] if cursor.description else []
                rows = [dict(zip(cols, row)) for row in cursor.fetchall()]
                return Response({'branches': rows}, status=status.HTTP_200_OK)
        except Exception as e:
            # Return a clear error message for frontend and log server-side
            err_msg = str(e)
            return Response({'error': f'Error fetching branches: {err_msg}'}, status=status.HTTP_200_OK)


class BranchManagerByCityView(APIView):
    """Return branch manager (BM) data for a given city_of_bm."""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        bm_id = request.query_params.get('bm_id')
        city = request.query_params.get('city', '').strip()
        if not bm_id and not city:
            return Response({'error': 'bm_id or city parameter required'}, status=status.HTTP_400_BAD_REQUEST)
        try:
            with connection.cursor() as cursor:
                if bm_id:
                    cursor.execute("SELECT * FROM branch_manager WHERE bm_id = %s LIMIT 1", [bm_id])
                else:
                    # Fallback: try to match by name_of_bm if city provided (less reliable)
                    cursor.execute("SELECT * FROM branch_manager WHERE name_of_bm = %s LIMIT 1", [city])
                cols = [c[0] for c in cursor.description] if cursor.description else []
                row = cursor.fetchone()
                if not row:
                    return Response({'bm': None}, status=status.HTTP_200_OK)
                data = dict(zip(cols, row))
                return Response({'bm': data}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': f'Error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class DirectorListView(APIView):
    """Return list of director names from director table."""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        # If a specific director name is provided, return full director row (useful to fetch phone_number_of_lolc)
        name = request.query_params.get('name')
        try:
            with connection.cursor() as cursor:
                if name:
                    cursor.execute("SELECT * FROM director WHERE name_of_director = %s LIMIT 1", [name])
                    cols = [c[0] for c in cursor.description] if cursor.description else []
                    row = cursor.fetchone()
                    if not row:
                        return Response({'director': None}, status=status.HTTP_200_OK)
                    data = dict(zip(cols, row))
                    return Response({'director': data}, status=status.HTTP_200_OK)
                else:
                    cursor.execute("SELECT DISTINCT name_of_director FROM director ORDER BY name_of_director")
                    rows = [row[0] for row in cursor.fetchall()]
                    return Response({'directors': rows}, status=status.HTTP_200_OK)
        except Exception as e:
            return Response({'error': f'Error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class BLAgreementDocxDownloadView(APIView):
    """Generate a DOCX from template for a given contract_number and return as attachment."""
    permission_classes = []

    def get(self, request):
        contract_number = request.query_params.get('contract_number', '').strip()
        if not contract_number:
            return Response({'error': 'contract_number parameter required'}, status=status.HTTP_400_BAD_REQUEST)

        # allow client to request an alternate template by filename (basename only)
        req_template = (request.query_params.get('template') or '').strip()
        if req_template:
            # sanitize to basename and ensure .docx extension
            req_template = os.path.basename(req_template)
            if not req_template.lower().endswith('.docx'):
                req_template = req_template + '.docx'
            template_path = os.path.join(settings.BASE_DIR, 'templates', 'docx', req_template)
        else:
            # default template
            template_path = os.path.join(settings.BASE_DIR, 'templates', 'docx', 'bl_agreement_template.docx')

        if not os.path.exists(template_path):
            return Response({'error': f'Template not found at {template_path}. Please place your .docx template there.'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        try:
            # Fetch data for the contract from bl_agreement and bl_collateral (if available)
            with connection.cursor() as cursor:
                cursor.execute('SELECT * FROM bl_agreement WHERE contract_number=%s LIMIT 1', [contract_number])
                agreement_row = cursor.fetchone()
                agreement_cols = [c[0] for c in cursor.description] if cursor.description else []
                agreement = dict(zip(agreement_cols, agreement_row)) if agreement_row else {}

                cursor.execute('SELECT * FROM bl_collateral WHERE contract_number=%s LIMIT 1', [contract_number])
                coll_row = cursor.fetchone()
                coll_cols = [c[0] for c in cursor.description] if cursor.description else []
                collateral = dict(zip(coll_cols, coll_row)) if coll_row else {}

            # Build context for the template
            # Flatten agreement and collateral dicts into top-level variables expected by the .docx template
            ctx = {}
            # agreement fields take precedence
            if isinstance(agreement, dict):
                for k, v in agreement.items():
                    ctx[k] = v
            if isinstance(collateral, dict):
                for k, v in collateral.items():
                    # do not override agreement fields
                    if k not in ctx:
                        ctx[k] = v
            # always include contract_number
            ctx['contract_number'] = contract_number

            # Derived / formatted fields for template convenience
            # Numeric fields: provide formatted with dot thousands and _in_word
            numeric_keys = ['loan_amount', 'admin_fee', 'net_amount', 'notaris_fee', 'mortgage_amount']
            for nk in numeric_keys:
                val = ctx.get(nk)
                try:
                    # formatted number with dot thousands
                    ctx[nk] = format_number_dot(val) if val is not None else ''
                except Exception:
                    ctx[nk] = val
                # words
                try:
                    ctx[nk + '_in_word'] = number_to_indonesian_words(val) if val is not None else ''
                except Exception:
                    ctx[nk + '_in_word'] = ''

            # Date fields: provide human-readable Indonesian date strings
            date_keys = ['agreement_date', 'date_birth_of_debtor', 'date_birth_of_bm', 'sp3_date', 'date_of_delegated']
            for dk in date_keys:
                v = ctx.get(dk)
                try:
                    # human-readable date (e.g., '6 September 2026')
                    ctx[dk] = format_indonesian_date(v) if v else ''
                    # spelled-out lowercase date (e.g., 'enam september dua ribu dua puluh enam')
                    ctx[dk + '_in_word'] = date_to_indonesian_words(v) if v else ''
                except Exception:
                    ctx[dk + '_in_word'] = ''

            # Uppercase names as requested
            try:
                if ctx.get('name_of_debtor'):
                    ctx['name_of_debtor'] = str(ctx.get('name_of_debtor')).upper()
            except Exception:
                pass
            try:
                if ctx.get('name_of_bm'):
                    ctx['name_of_bm'] = str(ctx.get('name_of_bm')).upper()
            except Exception:
                pass

            # agreement day in words (if agreement_date present)
            try:
                if ctx.get('agreement_date'):
                    from datetime import datetime
                    s = str(ctx.get('agreement_date'))
                    try:
                        d = datetime.fromisoformat(s).date()
                    except Exception:
                        try:
                            d = datetime.strptime(s, '%Y-%m-%d').date()
                        except Exception:
                            d = None
                    if d:
                        ctx['agreement_day_in_word'] = number_to_indonesian_words(d.day)
                    else:
                        ctx['agreement_day_in_word'] = ''
                else:
                    ctx['agreement_day_in_word'] = ''
            except Exception:
                ctx['agreement_day_in_word'] = ''

            # Render DOCX using docxtpl
            try:
                from docxtpl import DocxTemplate
            except Exception as imp_e:
                # Log diagnostic info to help identify which Python/environment is running
                try:
                    logs_dir = os.path.join(settings.BASE_DIR, 'logs')
                    os.makedirs(logs_dir, exist_ok=True)
                    diag_path = os.path.join(logs_dir, 'bl_agreement_docx_import_diag.log')
                    with open(diag_path, 'a', encoding='utf-8') as df:
                        df.write(f"[{timezone.now().isoformat()}] docxtpl import failed: {str(imp_e)}\n")
                        df.write(f"executable: {sys.executable}\n")
                        df.write(f"python_version: {sys.version}\n")
                        df.write(f"sys.path:\n")
                        for p in sys.path:
                            df.write(f"  {p}\n")
                        df.write("\n")
                except Exception:
                    pass
                logger.error('docxtpl import failed: %s', str(imp_e))
                if getattr(settings, 'DEBUG', False):
                    return Response({'error': 'docxtpl import failed', 'detail': str(imp_e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
                return Response({'error': 'docxtpl not installed. Please install with `pip install docxtpl`.'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

            # Preprocess template to repair Jinja tags that were split across
            # Word XML runs (common when template was edited in Word).
            def _repair_docx_jinja_tags(src_path, contract_no=None):
                try:
                    tmpdir = tempfile.mkdtemp(prefix='docx_repair_')
                    with zipfile.ZipFile(src_path, 'r') as zin:
                        zin.extractall(tmpdir)

                    word_dir = os.path.join(tmpdir, 'word')
                    if not os.path.exists(word_dir):
                        shutil.rmtree(tmpdir)
                        return src_path

                    changed_files = []

                    # process all xml files under word/ (document, headers, footers, notes, comments)
                    for root, dirs, files in os.walk(word_dir):
                        for fname in files:
                            if not fname.lower().endswith('.xml'):
                                continue
                            fullpath = os.path.join(root, fname)
                            with open(fullpath, 'r', encoding='utf-8') as f:
                                data = f.read()
                            # Normalize problematic Unicode characters that may
                            # break Jinja lexing when templates are embedded inside
                            # Word XML runs. Replace with safe ASCII equivalents.
                            if '\u2026' in data:
                                data = data.replace('\u2026', '...')
                            # common problematic characters: NBSP, ZWSP, BOM, soft hyphen, fancy quotes, dashes
                            replacements = {
                                '\u00A0': ' ', '\u200B': '', '\u200C': '', '\u200D': '', '\u00AD': '', '\ufeff': '',
                                '\u2018': "'", '\u2019': "'", '\u201C': '"', '\u201D': '"',
                                '\u2013': '-', '\u2014': '-', '\u2010': '-', '\u2022': '*'
                            }
                            for k, v in replacements.items():
                                if k in data:
                                    data = data.replace(k, v)

                            if '{{' not in data or '}}' not in data:
                                continue

                            orig = data
                            new = []
                            pos = 0
                            L = len(data)
                            while pos < L:
                                i = data.find('{{', pos)
                                if i == -1:
                                    new.append(data[pos:])
                                    break
                                # append before
                                new.append(data[pos:i])
                                j = data.find('}}', i)
                                if j == -1:
                                    # unterminated, append rest and break
                                    new.append(data[i:])
                                    break
                                segment = data[i:j+2]
                                # remove XML tags inside the segment
                                cleaned = re.sub(r'<[^>]+>', '', segment)
                                # normalize whitespace inside the braces
                                if cleaned.count('{{') and cleaned.count('}}'):
                                    inner_start = cleaned.find('{{') + 2
                                    inner_end = cleaned.rfind('}}')
                                    inner = cleaned[inner_start:inner_end]
                                    # remove all whitespace inside the jinja expression to
                                    # fix cases where Word split tokens across runs and
                                    # inserted spaces (e.g. "flate_rate _by_word").
                                    inner = re.sub(r'\s+', '', inner)
                                    cleaned_full = '{{' + inner + '}}'
                                    new.append(cleaned_full)
                                else:
                                    # fallback to raw cleaned (if braces disappeared)
                                    cleaned2 = re.sub(r'<[^>]+>', '', segment)
                                    new.append(cleaned2)
                                pos = j+2

                            repaired = ''.join(new)
                            if repaired != orig:
                                with open(fullpath, 'w', encoding='utf-8') as f:
                                    f.write(repaired)
                                rel = os.path.relpath(fullpath, tmpdir)
                                changed_files.append(rel.replace('\\', '/'))

                    if changed_files:
                        # create repaired docx
                        repaired_fd, repaired_path = tempfile.mkstemp(suffix='.docx')
                        os.close(repaired_fd)
                        with zipfile.ZipFile(repaired_path, 'w', zipfile.ZIP_DEFLATED) as zout:
                            for root, dirs, files in os.walk(tmpdir):
                                for file in files:
                                    full = os.path.join(root, file)
                                    arcname = os.path.relpath(full, tmpdir)
                                    zout.write(full, arcname)

                        # log repair info
                        try:
                            logs_dir = os.path.join(settings.BASE_DIR, 'logs')
                            os.makedirs(logs_dir, exist_ok=True)
                            repair_log = os.path.join(logs_dir, 'bl_agreement_docx_repair.log')
                            with open(repair_log, 'a', encoding='utf-8') as lf:
                                lf.write(f"[{timezone.now().isoformat()}] repaired={repaired_path} contract={contract_no} files={changed_files}\n")
                        except Exception:
                            pass

                        shutil.rmtree(tmpdir)
                        return repaired_path
                    else:
                        shutil.rmtree(tmpdir)
                        return src_path
                except Exception:
                    try:
                        shutil.rmtree(tmpdir)
                    except Exception:
                        pass
                    return src_path

            repaired_template = _repair_docx_jinja_tags(template_path, contract_no=contract_number)
            try:
                logs_dir = os.path.join(settings.BASE_DIR, 'logs')
                os.makedirs(logs_dir, exist_ok=True)
                with open(os.path.join(logs_dir, 'bl_agreement_docx_repair.log'), 'a', encoding='utf-8') as lf:
                    lf.write(f"[{timezone.now().isoformat()}] using_template={repaired_template} contract={contract_number}\n")
            except Exception:
                pass
            tpl = DocxTemplate(repaired_template)
            fallback_docx_path = None
            try:
                tpl.render(ctx)
            except Exception as render_e:
                logger.error('docxtpl render failed for %s: %s', repaired_template, str(render_e))
                try:
                    from docx import Document as _DocxDocument
                    doc_fallback = _DocxDocument()
                    doc_fallback.add_heading(f'BL Agreement - {contract_number}', level=1)
                    for k in ('sp3_number', 'sp3_date', 'name_of_debtor', 'contract_number'):
                        v = ctx.get(k, '')
                        doc_fallback.add_paragraph(f"{k}: {v}")
                    try:
                        hdr = ctx.get('header_fields') or ctx.get('header') or {}
                        if isinstance(hdr, dict) and hdr:
                            doc_fallback.add_heading('Header Fields', level=2)
                            for hk, hv in hdr.items():
                                doc_fallback.add_paragraph(f"{hk}: {hv}")
                    except Exception:
                        pass
                    fd, fbpath = tempfile.mkstemp(suffix='.docx')
                    os.close(fd)
                    doc_fallback.save(fbpath)
                    fallback_docx_path = fbpath
                    tpl = None
                except Exception as docx_e:
                    logger.error('Fallback DOCX generation failed: %s', str(docx_e))
                    raise

            # save to temporary file and return as attachment
            tmpdir = tempfile.mkdtemp(prefix='docx_out_')
            try:
                docx_path = os.path.join(tmpdir, f'bl_agreement_{contract_number}.docx')
                if tpl is not None:
                    tpl.save(docx_path)
                else:
                    if fallback_docx_path and os.path.exists(fallback_docx_path):
                        shutil.copyfile(fallback_docx_path, docx_path)
                        try:
                            os.remove(fallback_docx_path)
                        except Exception:
                            pass
                    else:
                        raise
                # If client requested PDF, attempt conversion (Windows/MS Word required for docx2pdf)
                # Accept either `format=pdf` or `as_pdf=1|true` as request parameters to request PDF output.
                req_format = request.query_params.get('format', '').lower()
                as_pdf_flag = str(request.query_params.get('as_pdf', '')).lower()
                wants_pdf = (req_format == 'pdf') or (as_pdf_flag in ('1', 'true', 'yes'))
                if wants_pdf:
                    try:
                        from docx2pdf import convert
                    except Exception as e:
                        logger.warning('docx2pdf import failed, falling back to DOCX: %s', str(e))
                        # docx2pdf not available — fall back to returning the DOCX
                        try:
                            path_to_read = None
                            if os.path.exists(docx_path):
                                path_to_read = docx_path
                            elif fallback_docx_path and os.path.exists(fallback_docx_path):
                                path_to_read = fallback_docx_path
                            else:
                                # try to find any .docx inside tmpdir as a last resort
                                try:
                                    files = os.listdir(tmpdir)
                                    for fn in files:
                                        if fn.lower().endswith('.docx'):
                                            candidate = os.path.join(tmpdir, fn)
                                            if os.path.exists(candidate):
                                                path_to_read = candidate
                                                break
                                except Exception:
                                    path_to_read = None

                            if not path_to_read:
                                # log diagnostic listing for debugging
                                try:
                                    logs_dir = os.path.join(settings.BASE_DIR, 'logs')
                                    os.makedirs(logs_dir, exist_ok=True)
                                    diag = os.path.join(logs_dir, 'bl_agreement_docx_errors.log')
                                    with open(diag, 'a', encoding='utf-8') as lf:
                                        lf.write(f"[{timezone.now().isoformat()}] Fallback DOCX not found for {contract_number} tmpdir={tmpdir} docx_path={docx_path} fallback={fallback_docx_path}\n")
                                        try:
                                            lf.write('tmpdir listing:\n')
                                            for root, dirs, files in os.walk(tmpdir):
                                                for f in files:
                                                    lf.write(f"  {os.path.join(root, f)}\n")
                                        except Exception:
                                            pass
                                except Exception:
                                    pass
                                logger.error('Fallback DOCX not found for %s (checked docx_path, fallback_docx_path, tmpdir).', contract_number)
                                return Response({'error': 'docx2pdf not available and DOCX fallback missing on server.'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

                            with open(path_to_read, 'rb') as fh:
                                docx_bytes = fh.read()
                            response = HttpResponse(docx_bytes, content_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document')
                            response['Content-Disposition'] = f'attachment; filename="bl_agreement_{contract_number}.docx"'
                            return response
                        except Exception as e2:
                            logger.error('Failed to return fallback DOCX for %s: %s', contract_number, str(e2))
                            return Response({'error': 'docx2pdf not available and DOCX fallback failed.'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

                    pdf_path = os.path.join(tmpdir, f'bl_agreement_{contract_number}.pdf')
                    try:
                        # convert expects Windows with MS Word; convert single file to specified output
                        # Ensure COM is initialized on this thread before calling Word automation.
                        try:
                            import pythoncom
                            pythoncom.CoInitialize()
                        except Exception:
                            pythoncom = None
                        try:
                            convert(docx_path, pdf_path)
                        finally:
                            try:
                                if pythoncom is not None:
                                    pythoncom.CoUninitialize()
                            except Exception:
                                pass
                        with open(pdf_path, 'rb') as pf:
                            pdf_bytes = pf.read()
                        response = HttpResponse(pdf_bytes, content_type='application/pdf')
                        response['Content-Disposition'] = f'attachment; filename="bl_agreement_{contract_number}.pdf"'
                        return response
                    except Exception as conv_e:
                        logger.error('docx2pdf conversion failed for %s: %s', docx_path, str(conv_e))
                        if getattr(settings, 'DEBUG', False):
                            return Response({'error': 'PDF conversion failed', 'detail': str(conv_e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
                        return Response({'error': 'Failed to convert DOCX to PDF on server.'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
            finally:
                try:
                    _safe_rmtree(tmpdir)
                except Exception:
                    pass
                # cleaned up temporary dir; do not attempt to read files here

        except Exception as e:
            # Capture full traceback and write to server log file for debugging
            tb = traceback.format_exc()
            try:
                logs_dir = os.path.join(settings.BASE_DIR, 'logs')
                os.makedirs(logs_dir, exist_ok=True)
                log_path = os.path.join(logs_dir, 'bl_agreement_docx_errors.log')
                with open(log_path, 'a', encoding='utf-8') as lf:
                    lf.write(f"[{timezone.now().isoformat()}] Error generating docx for {contract_number}\n")
                    lf.write(tb + "\n")
            except Exception:
                # ignore logging errors
                pass

            logger.error('Error generating DOCX for %s: %s', contract_number, tb)

            if getattr(settings, 'DEBUG', False):
                return Response({'error': str(e), 'traceback': tb}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
            return Response({'error': 'Internal server error while generating DOCX. Check server logs.'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


class UVAgreementDocxDownloadView(APIView):
    """Generate a DOCX from UV template for a given contract_number and return as attachment."""
    permission_classes = []

    def get(self, request):
        contract_number = request.query_params.get('contract_number', '').strip()
        if not contract_number:
            return Response({'error': 'contract_number parameter required'}, status=status.HTTP_400_BAD_REQUEST)

        # locate UV template file
        template_path = os.path.join(settings.BASE_DIR, 'templates', 'docx', 'uv_agreement_template.docx')
        if not os.path.exists(template_path):
            return Response({'error': f'UV template not found at {template_path}. Please place your .docx template there.'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        try:
            # Fetch data for the contract from uv_agreement and uv_collateral (if available)
            with connection.cursor() as cursor:
                cursor.execute('SELECT * FROM uv_agreement WHERE contract_number=%s LIMIT 1', [contract_number])
                agreement_row = cursor.fetchone()
                agreement_cols = [c[0] for c in cursor.description] if cursor.description else []
                agreement = dict(zip(agreement_cols, agreement_row)) if agreement_row else {}

                cursor.execute('SELECT * FROM uv_collateral WHERE contract_number=%s LIMIT 1', [contract_number])
                coll_row = cursor.fetchone()
                coll_cols = [c[0] for c in cursor.description] if cursor.description else []
                collateral = dict(zip(coll_cols, coll_row)) if coll_row else {}

            ctx = {}
            if isinstance(agreement, dict):
                for k, v in agreement.items():
                    ctx[k] = v
            if isinstance(collateral, dict):
                for k, v in collateral.items():
                    if k not in ctx:
                        ctx[k] = v
            ctx['contract_number'] = contract_number

            # Derived fields: numeric formatting and in-word
            numeric_keys = ['loan_amount', 'admin_fee', 'net_amount', 'notaris_fee', 'mortgage_amount']
            for nk in numeric_keys:
                val = ctx.get(nk)
                try:
                    ctx[nk] = format_number_dot(val) if val is not None else ''
                except Exception:
                    ctx[nk] = val
                try:
                    ctx[nk + '_in_word'] = number_to_indonesian_words(val) if val is not None else ''
                except Exception:
                    ctx[nk + '_in_word'] = ''

            date_keys = ['agreement_date', 'date_birth_of_debtor', 'sp3_date']
            for dk in date_keys:
                v = ctx.get(dk)
                try:
                    ctx[dk] = format_indonesian_date(v) if v else ''
                    ctx[dk + '_in_word'] = date_to_indonesian_words(v) if v else ''
                except Exception:
                    ctx[dk + '_in_word'] = ''

            try:
                if ctx.get('name_of_debtor'):
                    ctx['name_of_debtor'] = str(ctx.get('name_of_debtor')).upper()
            except Exception:
                pass

            try:
                from docxtpl import DocxTemplate
            except Exception as imp_e:
                logger.error('docxtpl import failed for UV: %s', str(imp_e))
                if getattr(settings, 'DEBUG', False):
                    return Response({'error': 'docxtpl import failed', 'detail': str(imp_e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
                return Response({'error': 'docxtpl not installed. Please install with `pip install docxtpl`.'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

            def _repair_docx_jinja_tags_uv(src_path, contract_no=None):
                # reuse same repair logic as BL but keep function name distinct
                try:
                    tmpdir = tempfile.mkdtemp(prefix='docx_repair_uv_')
                    with zipfile.ZipFile(src_path, 'r') as zin:
                        zin.extractall(tmpdir)

                    word_dir = os.path.join(tmpdir, 'word')
                    if not os.path.exists(word_dir):
                        shutil.rmtree(tmpdir)
                        return src_path

                    changed_files = []
                    for root, dirs, files in os.walk(word_dir):
                        for fname in files:
                            if not fname.lower().endswith('.xml'):
                                continue
                            fullpath = os.path.join(root, fname)
                            with open(fullpath, 'r', encoding='utf-8') as f:
                                data = f.read()
                            # Normalize problematic Unicode characters
                            if '\u2026' in data:
                                data = data.replace('\u2026', '...')
                            replacements = {
                                '\u00A0': ' ', '\u200B': '', '\u200C': '', '\u200D': '', '\u00AD': '', '\ufeff': '',
                                '\u2018': "'", '\u2019': "'", '\u201C': '"', '\u201D': '"',
                                '\u2013': '-', '\u2014': '-', '\u2010': '-', '\u2022': '*'
                            }
                            for k, v in replacements.items():
                                if k in data:
                                    data = data.replace(k, v)
                            if '{{' not in data or '}}' not in data:
                                continue
                            orig = data
                            new = []
                            pos = 0
                            L = len(data)
                            while pos < L:
                                i = data.find('{{', pos)
                                if i == -1:
                                    new.append(data[pos:])
                                    break
                                new.append(data[pos:i])
                                j = data.find('}}', i)
                                if j == -1:
                                    new.append(data[i:])
                                    break
                                segment = data[i:j+2]
                                cleaned = re.sub(r'<[^>]+>', '', segment)
                                if cleaned.count('{{') and cleaned.count('}}'):
                                    inner_start = cleaned.find('{{') + 2
                                    inner_end = cleaned.rfind('}}')
                                    inner = cleaned[inner_start:inner_end]
                                    inner = re.sub(r'\s+', '', inner)
                                    cleaned_full = '{{' + inner + '}}'
                                    new.append(cleaned_full)
                                else:
                                    cleaned2 = re.sub(r'<[^>]+>', '', segment)
                                    new.append(cleaned2)
                                pos = j+2
                            repaired = ''.join(new)
                            if repaired != orig:
                                with open(fullpath, 'w', encoding='utf-8') as f:
                                    f.write(repaired)
                                rel = os.path.relpath(fullpath, tmpdir)
                                changed_files.append(rel.replace('\\', '/'))

                    if changed_files:
                        repaired_fd, repaired_path = tempfile.mkstemp(suffix='.docx')
                        os.close(repaired_fd)
                        with zipfile.ZipFile(repaired_path, 'w', zipfile.ZIP_DEFLATED) as zout:
                            for root, dirs, files in os.walk(tmpdir):
                                for file in files:
                                    full = os.path.join(root, file)
                                    arcname = os.path.relpath(full, tmpdir)
                                    zout.write(full, arcname)
                        try:
                            logs_dir = os.path.join(settings.BASE_DIR, 'logs')
                            os.makedirs(logs_dir, exist_ok=True)
                            repair_log = os.path.join(logs_dir, 'uv_agreement_docx_repair.log')
                            with open(repair_log, 'a', encoding='utf-8') as lf:
                                lf.write(f"[{timezone.now().isoformat()}] repaired={repaired_path} contract={contract_no} files={changed_files}\n")
                        except Exception:
                            pass
                        shutil.rmtree(tmpdir)
                        return repaired_path
                    else:
                        shutil.rmtree(tmpdir)
                        return src_path
                except Exception:
                    try:
                        shutil.rmtree(tmpdir)
                    except Exception:
                        pass
                    return src_path

            repaired_template = _repair_docx_jinja_tags_uv(template_path, contract_no=contract_number)
            tpl = DocxTemplate(repaired_template)
            fallback_docx_path = None
            try:
                tpl.render(ctx)
            except Exception as render_e:
                logger.error('docxtpl render failed for UV %s: %s', repaired_template, str(render_e))
                try:
                    from docx import Document as _DocxDocument
                    doc_fallback = _DocxDocument()
                    doc_fallback.add_heading(f'UV Agreement - {contract_number}', level=1)
                    for k in ('sp3_number', 'sp3_date', 'name_of_debtor', 'contract_number'):
                        v = ctx.get(k, '')
                        doc_fallback.add_paragraph(f"{k}: {v}")
                    try:
                        hdr = ctx.get('header_fields') or ctx.get('header') or {}
                        if isinstance(hdr, dict) and hdr:
                            doc_fallback.add_heading('Header Fields', level=2)
                            for hk, hv in hdr.items():
                                doc_fallback.add_paragraph(f"{hk}: {hv}")
                    except Exception:
                        pass
                    fd, fbpath = tempfile.mkstemp(suffix='.docx')
                    os.close(fd)
                    doc_fallback.save(fbpath)
                    fallback_docx_path = fbpath
                    tpl = None
                except Exception as docx_e:
                    logger.error('Fallback DOCX generation failed for UV: %s', str(docx_e))
                    raise

            tmpdir = tempfile.mkdtemp(prefix='docx_out_uv_')
            try:
                docx_path = os.path.join(tmpdir, f'uv_agreement_{contract_number}.docx')
                if tpl is not None:
                    tpl.save(docx_path)
                else:
                    if fallback_docx_path and os.path.exists(fallback_docx_path):
                        shutil.copyfile(fallback_docx_path, docx_path)
                        try:
                            os.remove(fallback_docx_path)
                        except Exception:
                            pass
                    else:
                        raise
                req_format = request.query_params.get('format', '').lower()
                as_pdf_flag = str(request.query_params.get('as_pdf', '')).lower()
                wants_pdf = (req_format == 'pdf') or (as_pdf_flag in ('1', 'true', 'yes'))
                if wants_pdf:
                    try:
                        from docx2pdf import convert
                    except Exception as e:
                        logger.warning('docx2pdf import failed for UV, falling back to DOCX: %s', str(e))
                        try:
                            with open(docx_path, 'rb') as fh:
                                docx_bytes = fh.read()
                            response = HttpResponse(docx_bytes, content_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document')
                            response['Content-Disposition'] = f'attachment; filename="uv_agreement_{contract_number}.docx"'
                            return response
                        except Exception as e2:
                            logger.error('Failed to return fallback UV DOCX for %s: %s', contract_number, str(e2))
                            return Response({'error': 'docx2pdf not available and DOCX fallback failed.'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

                    pdf_path = os.path.join(tmpdir, f'uv_agreement_{contract_number}.pdf')
                    try:
                        try:
                            import pythoncom
                            pythoncom.CoInitialize()
                        except Exception:
                            pythoncom = None
                        try:
                            convert(docx_path, pdf_path)
                        finally:
                            try:
                                if pythoncom is not None:
                                    pythoncom.CoUninitialize()
                            except Exception:
                                pass
                        with open(pdf_path, 'rb') as pf:
                            pdf_bytes = pf.read()
                        response = HttpResponse(pdf_bytes, content_type='application/pdf')
                        response['Content-Disposition'] = f'attachment; filename="uv_agreement_{contract_number}.pdf"'
                        return response
                    except Exception as conv_e:
                        logger.error('docx2pdf conversion failed for UV %s: %s', docx_path, str(conv_e))
                        if getattr(settings, 'DEBUG', False):
                            return Response({'error': 'PDF conversion failed', 'detail': str(conv_e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
                        return Response({'error': 'Failed to convert DOCX to PDF on server.'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
            finally:
                try:
                    _safe_rmtree(tmpdir)
                except Exception:
                    pass

        except Exception as e:
            tb = traceback.format_exc()
            try:
                logs_dir = os.path.join(settings.BASE_DIR, 'logs')
                os.makedirs(logs_dir, exist_ok=True)
                log_path = os.path.join(logs_dir, 'uv_agreement_docx_errors.log')
                with open(log_path, 'a', encoding='utf-8') as lf:
                    lf.write(f"[{timezone.now().isoformat()}] Error generating UV docx for {contract_number}\n")
                    lf.write(tb + "\n")
            except Exception:
                pass
            logger.error('Error generating UV DOCX for %s: %s', contract_number, tb)
            if getattr(settings, 'DEBUG', False):
                return Response({'error': str(e), 'traceback': tb}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
            return Response({'error': 'Internal server error while generating UV DOCX. Check server logs.'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)