﻿/* eslint-disable unicode-bom, no-unused-vars, react-hooks/exhaustive-deps */
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../UserManagement/UserManagement.css';
import BLAgreementForm from './AgreementForm';

// Sediakan pembungkus lokal sehingga Create/Edit dapat diimpor dari file ini
export function BLAgreementCreate(props = {}) {
  return <BLAgreementForm {...props} createOnly={true} editOnly={false} hideFilter={false} hideHeader={false} />;
}

export function BLAgreementEdit({ initialContractNumber = '', onSaved, ...rest } = {}) {
  return <BLAgreementForm initialContractNumber={initialContractNumber} onSaved={onSaved} createOnly={false} editOnly={true} hideFilter={true} hideHeader={true} {...rest} />;
}

export default function BLAgreement() {
  const [agreements, setAgreements] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [modalMode, setModalMode] = useState('create'); // 'create' or 'edit'
  const [contractNumber, setContractNumber] = useState('');
  const [formDebtorName, setFormDebtorName] = useState('');
  const [formNik, setFormNik] = useState('');
  const [formCollateralType, setFormCollateralType] = useState('');
  const [savingModal, setSavingModal] = useState(false);
  const [contractOnlyMode, setContractOnlyMode] = useState(false);
  const [collateralMode, setCollateralMode] = useState(false);
  const [lastSavedContract, setLastSavedContract] = useState(null);
  const [collateralForm, setCollateralForm] = useState({
    contract_number: '',
    name_of_debtor: '',
    collateral_type: '',
    number_of_certificate: '',
    number_of_ajb: '',
    surface_area: '',
    name_of_collateral_owner: '',
    capacity_of_building: '',
    location_of_land: ''
  });
  const [collateralSaving, setCollateralSaving] = useState(false);
  const [collateralError, setCollateralError] = useState('');

  const requestWithAuth = async (config) => {
    const doRequest = async (token) => {
      const headers = token ? { Authorization: `Bearer ${token}` } : {};
      return axios({ ...config, headers });
    };

    try {
      const access = localStorage.getItem('access_token');
      return await doRequest(access);
    } catch (err) {
      const respData = err?.response?.data || {};
      const isTokenExpired = respData.code === 'token_not_valid' || (respData.messages && Array.isArray(respData.messages) && respData.messages.some(m => m.message && m.message.toLowerCase().includes('expired')));
      if (err.response?.status === 401 || isTokenExpired) {
        try {
          const refresh = localStorage.getItem('refresh_token');
          if (!refresh) throw err;
          const r = await axios.post('http://localhost:8000/api/token/refresh/', { refresh });
          const newAccess = r.data.access;
          if (newAccess) {
            localStorage.setItem('access_token', newAccess);
            return await doRequest(newAccess);
          }
        } catch (refreshErr) {
          console.error('Token refresh failed', refreshErr);
          localStorage.removeItem('access_token');
          localStorage.removeItem('refresh_token');
          throw err;
        }
      }
      throw err;
    }
  };

  // Gaya field form lokal agar sesuai dengan form lain
  const fieldLabelStyle = { fontSize: 13, fontWeight: 600, color: '#333', marginBottom: 6 };
  const fieldInputStyle = { padding: '10px 12px', fontSize: 14, border: '1px solid #ddd', borderRadius: 6, outline: 'none', width: '100%', boxSizing: 'border-box' };
  const fieldGroupStyle = { display: 'flex', flexDirection: 'column' };

  useEffect(() => { loadAgreements(); }, []);

  const loadAgreements = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await requestWithAuth({ method: 'get', url: 'http://localhost:8000/api/bl-agreement/' });
      let items = res.data?.agreements || res.data?.results || res.data || [];
      if (!Array.isArray(items)) items = items ? [items] : [];
      const rows = items.map(item => ({
        agreement_date: item.agreement_date || item.header?.agreement_date || item.created_at || item.created || item.date_created || '',
        contract_number: item.contract_number || (item.contract && item.contract.contract_number) || '',
        name_of_debtor: (item.debtor || item.contract || {}).name_of_debtor || item.name_of_debtor || '',
        nik_number_of_debtor: (item.debtor || item.contract || {}).nik_number_of_debtor || item.nik_number_of_debtor || '',
        collateral_type: (item.collateral && item.collateral.collateral_type) || item.collateral_type || '',
        created_by: item.created_by || item.created_by_name || item.created_by_user || ''
      }));
      setAgreements(rows);
    } catch (err) {
      console.error('Error loading agreements', err);
      setError('Failed to load agreements');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = async (row) => {
    const cn = row.contract_number;
    setError('');
    if (!cn) {
      setModalMode('create'); setContractNumber(''); setFormDebtorName(''); setFormNik(''); setFormCollateralType(''); setShowCreateModal(true); return;
    }

    // Untuk Edit: JANGAN gabungkan nilai lokal — biarkan BLAgreement2 memuat semua data langsung
    setContractNumber(cn);
    setModalMode('edit');
    setShowCreateModal(true);
  };

  const fetchContractData = async (cn) => {
    try {
      const res = await requestWithAuth({ method: 'get', url: `http://localhost:8000/api/bl-agreement/?contract_number=${encodeURIComponent(cn)}` });
      // backend mengembalikan { debtor: ..., collateral: ... }
      return res.data || {};
    } catch (err) {
      console.error('Failed fetch contract', err);
      return {};
    }
  };

  const handleDownloadRow = async (row) => {
    if (!row.contract_number) { setError('Contract number not available'); return; }
    try {
      // Minta PDF jika tersedia
      const url = `http://localhost:8000/api/bl-agreement/download-docx/?contract_number=${encodeURIComponent(row.contract_number)}&as_pdf=1`;
      const res = await requestWithAuth({ method: 'get', url, responseType: 'blob' });
      const contentType = (res.headers && res.headers['content-type']) || '';
      const blob = new Blob([res.data], { type: contentType || 'application/octet-stream' });
      // If server returned JSON (error), parse and show message instead of downloading
      if (contentType.includes('application/json')) {
        const text = await blob.text();
        try {
          const js = JSON.parse(text);
          const msg = js.error || js.detail || JSON.stringify(js);
          setError(`Download failed: ${msg}`);
          return;
        } catch (e) {
          setError('Download failed: unable to parse server response');
          return;
        }
      }
      const isPdf = contentType.includes('pdf') || url.toLowerCase().includes('as_pdf=1');
      const link = document.createElement('a');
      link.href = window.URL.createObjectURL(blob);
      link.download = `bl_agreement_${row.contract_number}${isPdf ? '.pdf' : '.docx'}`;
      document.body.appendChild(link);
      link.click(); link.remove();
    } catch (err) {
      console.error('Download failed', err); setError('Failed to download the document');
    }
  };

  const handleSaveModal = async () => {
    setSavingModal(true);
    try {
      const payload = { contract_number: contractNumber, debtor: { name_of_debtor: formDebtorName, nik_number_of_debtor: formNik }, collateral: { collateral_type: formCollateralType } };
      await requestWithAuth({ method: 'post', url: 'http://localhost:8000/api/bl-agreement/', data: payload });
      setShowCreateModal(false);
      await loadAgreements();
    } catch (err) {
      console.error('Save failed', err);
      setError('Failed to save');
    } finally {
      setSavingModal(false);
    }
  };

  const handleSaveAndDownload = async () => {
    setSavingModal(true);
    try {
      const payload = { contract_number: contractNumber, debtor: { name_of_debtor: formDebtorName, nik_number_of_debtor: formNik }, collateral: { collateral_type: formCollateralType } };
      await requestWithAuth({ method: 'post', url: 'http://localhost:8000/api/bl-agreement/', data: payload });
      // refresh daftar lalu unduh
      await loadAgreements();
      // Request PDF when available
      const url = `http://localhost:8000/api/bl-agreement/download-docx/?contract_number=${encodeURIComponent(contractNumber)}&as_pdf=1`;
      const res = await requestWithAuth({ method: 'get', url, responseType: 'blob' });
      const contentType = (res.headers && res.headers['content-type']) || '';
      const blob = new Blob([res.data], { type: contentType || 'application/octet-stream' });
      if (contentType.includes('application/json')) {
        const text = await blob.text();
        try {
          const js = JSON.parse(text);
          const msg = js.error || js.detail || JSON.stringify(js);
          setError(`Download failed: ${msg}`);
          setShowCreateModal(false);
          setSavingModal(false);
          return;
        } catch (e) {
          setError('Download failed: unable to parse server response');
          setShowCreateModal(false);
          setSavingModal(false);
          return;
        }
      }
      const isPdf = contentType.includes('pdf') || url.toLowerCase().includes('as_pdf=1');
      const link = document.createElement('a'); link.href = window.URL.createObjectURL(blob); link.download = `bl_agreement_${contractNumber}${isPdf ? '.pdf' : '.docx'}`; document.body.appendChild(link); link.click(); link.remove();
      setShowCreateModal(false);
    } catch (err) {
      console.error('Save & Download failed', err);
      setError('Failed to save and download');
    } finally {
      setSavingModal(false);
    }
  };

  const handleModalDownload = async () => {
    if (!contractNumber) { setError('Contract number is empty'); return; }
    try {
      // Request PDF when available
      const url = `http://localhost:8000/api/bl-agreement/download-docx/?contract_number=${encodeURIComponent(contractNumber)}&as_pdf=1`;
      const res = await requestWithAuth({ method: 'get', url, responseType: 'blob' });
      const contentType = (res.headers && res.headers['content-type']) || '';
      const blob = new Blob([res.data], { type: contentType || 'application/octet-stream' });
      if (contentType.includes('application/json')) {
        const text = await blob.text();
        try {
          const js = JSON.parse(text);
          const msg = js.error || js.detail || JSON.stringify(js);
          setError(`Download failed: ${msg}`);
          return;
        } catch (e) {
          setError('Download failed: unable to parse server response');
          return;
        }
      }
      const isPdf = contentType.includes('pdf') || url.toLowerCase().includes('as_pdf=1');
      const link = document.createElement('a'); link.href = window.URL.createObjectURL(blob); link.download = `bl_agreement_${contractNumber}${isPdf ? '.pdf' : '.docx'}`; document.body.appendChild(link); link.click(); link.remove();
    } catch (err) { console.error('Download failed', err); setError('Failed to download the document'); }
  };

  const formatDateShort = (iso) => {
    if (!iso) return '';
    try { const d = new Date(iso); if (isNaN(d.getTime())) return iso; const dd = String(d.getDate()).padStart(2, '0'); const mm = String(d.getMonth() + 1).padStart(2, '0'); const yyyy = d.getFullYear(); return `${dd}-${mm}-${yyyy}`; } catch (e) { return iso; }
  };

  return (
    <div>
      <div>
        <h2>BL Agreement</h2>
        <p>Before creating the document, make sure to fill in the contract and collateral data first.</p>
      </div>

      <div className="user-management-actions" style={{ justifyContent: 'flex-end', marginTop: 0 }}>
        <button
          className="btn-primary"
          onClick={() => { setModalMode('create'); setContractNumber(''); setFormDebtorName(''); setFormNik(''); setFormCollateralType(''); setError(''); setContractOnlyMode(true); setShowCreateModal(true); }}
          title="Add a new contract"
        >
          Add Contract
        </button>

        <button
          className="btn-primary"
          onClick={() => { setModalMode('create'); setContractNumber(''); setFormDebtorName(''); setFormNik(''); setFormCollateralType(''); setError(''); setCollateralMode(true); setShowCreateModal(true); }}
          title="Add a new BL collateral"
        >
          Add Collateral
        </button>

        <button className="btn-save" onClick={() => { setModalMode('create'); setContractNumber(''); setFormDebtorName(''); setFormNik(''); setFormCollateralType(''); setError(''); setContractOnlyMode(false); setCollateralMode(false); setShowCreateModal(true); }}>Create Document</button>
      </div>

      <div className="user-table-section" style={{ marginTop: 12 }}>
        <div style={{ padding: 12 }}>
          

          {loading ? (
            <div>Loading...</div>
          ) : error ? (
            <div className="error-message">{error}</div>
          ) : (
            <div style={{ overflowX: 'auto' }}>
              <table className="user-table">
                <thead>
                  <tr>
                    <th>Agreement Date</th>
                    <th>Contract Number</th>
                    <th>Name of Debtor</th>
                    <th>NIK Debtor</th>
                    <th>Collateral Type</th>
                    <th>Created By</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {agreements.length === 0 ? (
                    <tr><td className="no-data" colSpan={7}>No agreements found.</td></tr>
                  ) : (
                    agreements.map((row) => (
                      <tr key={row.contract_number}>
                        <td>{formatDateShort(row.agreement_date)}</td>
                        <td>{row.contract_number}</td>
                        <td>{row.name_of_debtor}</td>
                        <td>{row.nik_number_of_debtor}</td>
                        <td>{row.collateral_type}</td>
                        <td>{row.created_by}</td>
                        <td>
                          <div style={{ display: 'flex', gap: 8 }}>
                            <button className="btn-edit" onClick={() => handleEdit(row)}>Edit</button>
                            <button className="btn-cancel" onClick={() => handleDownloadRow(row)}>Download</button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {showCreateModal && (
        <div className="modal-overlay" onClick={() => { setShowCreateModal(false); setContractOnlyMode(false); setCollateralMode(false); }}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
              <div className="modal-header">
              <h3 className="modal-title">
                {modalMode === 'edit' && contractNumber ? `Edit ${contractNumber}` : (
                  contractOnlyMode ? 'Add Contract' : (collateralMode ? 'Add Collateral' : 'Create Document')
                )}
              </h3>
              <button className="modal-close-btn" onClick={() => { setShowCreateModal(false); setContractOnlyMode(false); setCollateralMode(false); }}>&times;</button>
            </div>

            <div className="modal-form">
              {modalMode === 'edit' ? (
                <BLAgreementEdit
                  initialContractNumber={contractNumber}
                  onSaved={(cn) => { setShowCreateModal(false); setContractOnlyMode(false); loadAgreements(); if (cn) setContractNumber(cn); }}
                />
              ) : collateralMode ? (
                <div style={{ padding: 20, minWidth: 560 }}>
                  {collateralError && <div style={{ marginBottom: 12, color: '#a33' }}>{collateralError}</div>}

                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                    <div style={fieldGroupStyle}>
                      <label style={fieldLabelStyle}>Contract Number</label>
                      <input
                        type="text"
                        value={collateralForm.contract_number}
                        onChange={async (e) => {
                          const v = e.target.value;
                          setCollateralForm(prev => ({ ...prev, contract_number: v }));
                          if (v && v.trim()) {
                            try {
                              const data = await fetchContractData(v.trim());
                              const debtor = data.debtor || data || {};
                              const name = debtor.name_of_debtor || debtor.name || '';
                              setCollateralForm(prev => ({ ...prev, name_of_debtor: name }));
                            } catch (err) {
                              setCollateralForm(prev => ({ ...prev, name_of_debtor: '' }));
                            }
                          } else {
                            setCollateralForm(prev => ({ ...prev, name_of_debtor: '' }));
                          }
                        }}
                        style={fieldInputStyle}
                      />
                    </div>

                    <div style={fieldGroupStyle}>
                      <label style={fieldLabelStyle}>Name of Debtor</label>
                      <input type="text" value={collateralForm.name_of_debtor} disabled style={{ ...fieldInputStyle, backgroundColor: '#f5f5f5' }} />
                    </div>

                    <div style={fieldGroupStyle}>
                      <label style={fieldLabelStyle}>Collateral Type</label>
                      <input type="text" value={collateralForm.collateral_type} onChange={(e) => setCollateralForm(prev => ({ ...prev, collateral_type: e.target.value }))} style={fieldInputStyle} />
                    </div>

                    <div style={fieldGroupStyle}>
                      <label style={fieldLabelStyle}>Number of Certificate</label>
                      <input type="text" value={collateralForm.number_of_certificate} onChange={(e) => setCollateralForm(prev => ({ ...prev, number_of_certificate: e.target.value }))} style={fieldInputStyle} />
                    </div>

                    <div style={fieldGroupStyle}>
                      <label style={fieldLabelStyle}>Number of AJB</label>
                      <input type="text" value={collateralForm.number_of_ajb} onChange={(e) => setCollateralForm(prev => ({ ...prev, number_of_ajb: e.target.value }))} style={fieldInputStyle} />
                    </div>

                    <div style={fieldGroupStyle}>
                      <label style={fieldLabelStyle}>Surface Area</label>
                      <input type="text" value={collateralForm.surface_area} onChange={(e) => setCollateralForm(prev => ({ ...prev, surface_area: e.target.value }))} style={fieldInputStyle} />
                    </div>

                    <div style={fieldGroupStyle}>
                      <label style={fieldLabelStyle}>Name of Collateral Owner</label>
                      <input type="text" value={collateralForm.name_of_collateral_owner} onChange={(e) => setCollateralForm(prev => ({ ...prev, name_of_collateral_owner: e.target.value }))} style={fieldInputStyle} />
                    </div>

                    <div style={fieldGroupStyle}>
                      <label style={fieldLabelStyle}>Capacity of Building</label>
                      <input type="text" value={collateralForm.capacity_of_building} onChange={(e) => setCollateralForm(prev => ({ ...prev, capacity_of_building: e.target.value }))} style={fieldInputStyle} />
                    </div>

                    <div style={fieldGroupStyle}>
                      <label style={fieldLabelStyle}>Location of Land</label>
                      <input type="text" value={collateralForm.location_of_land} onChange={(e) => setCollateralForm(prev => ({ ...prev, location_of_land: e.target.value }))} style={fieldInputStyle} />
                    </div>
                  </div>

                  <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 16 }}>
                    <button className="btn-save" onClick={async () => {
                      setCollateralSaving(true); setCollateralError('');
                      try {
                        const payload = {
                          contract_number: collateralForm.contract_number,
                          collateral_type: collateralForm.collateral_type,
                          number_of_certificate: collateralForm.number_of_certificate,
                          number_of_ajb: collateralForm.number_of_ajb,
                          surface_area: collateralForm.surface_area,
                          name_of_collateral_owner: collateralForm.name_of_collateral_owner,
                          capacity_of_building: collateralForm.capacity_of_building,
                          location_of_land: collateralForm.location_of_land
                        };
                        await requestWithAuth({ method: 'post', url: 'http://localhost:8000/api/bl-collateral/', data: payload });
                        setShowCreateModal(false);
                        setCollateralMode(false);
                        loadAgreements();
                        setSuccessMessage('Collateral data saved successfully');
                        setTimeout(() => setSuccessMessage(''), 4000);
                      } catch (err) {
                        console.error('Save collateral failed', err);
                        const msg = err?.response?.data?.error || 'Failed to save collateral';
                        setCollateralError(msg);
                      } finally {
                        setCollateralSaving(false);
                      }
                    }} disabled={collateralSaving}>{collateralSaving ? 'Saving...' : 'Save Collateral'}</button>
                  </div>
                </div>
              ) : (
                <BLAgreementCreate
                  initialContractData={lastSavedContract}
                  contractOnly={contractOnlyMode}
                  onContractSaved={(saved) => {
                    // Jika pengguna membatalkan entri kontrak, tutup modal
                    if (!saved) {
                      setShowCreateModal(false);
                      setContractOnlyMode(false);
                      return;
                    }
                    // Setelah menyimpan kontrak: tutup modal, refresh daftar, tampilkan notifikasi sukses
                    setLastSavedContract(saved || null);
                    setShowCreateModal(false);
                    setContractOnlyMode(false);
                    loadAgreements();
                    setSuccessMessage('Contract data saved successfully');
                    // hapus otomatis pesan sukses setelah 4 detik
                    setTimeout(() => setSuccessMessage(''), 4000);
                  }}
                  onSaved={(cn) => { setShowCreateModal(false); setContractOnlyMode(false); loadAgreements(); if (cn) setContractNumber(cn); }}
                />
              )}
            </div>

            {/* modal footer intentionally left without a bottom Cancel/Close button per UI preference */}
          </div>
        </div>
      )}

      
    </div>
  );
}
