import React from 'react';

function BLSP3() {
  return (
    <div>
      <h2>BL SP3</h2>
      <p>Before creating the document, make sure to fill in the contract and collateral data first.</p>
      <p>Belum huhuhu.</p>
    </div>
  );
}

export default BLSP3;
