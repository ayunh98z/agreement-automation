/* eslint-disable unicode-bom, no-unused-vars, react-hooks/exhaustive-deps */
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../UserManagement/UserManagement.css';
import AgreementForm from './AgreementForm';
import { buildCollateralPayload } from './collateralUtils';

// Sediakan pembungkus lokal untuk UV sehingga Create/Edit dapat diimpor dari file ini
export function UVAgreementCreate(props = {}) {
  return <AgreementForm {...props} createOnly={true} editOnly={false} hideFilter={false} hideHeader={false} isUV={true} />;
}

export function UVAgreementEdit({ initialContractNumber = '', onSaved, ...rest } = {}) {
  return <AgreementForm initialContractNumber={initialContractNumber} onSaved={onSaved} createOnly={false} editOnly={true} hideFilter={true} hideHeader={true} isUV={true} {...rest} />;
}

export default function UVAgreement() {
  const [agreements, setAgreements] = useState([]);
  const [columns, setColumns] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [modalMode, setModalMode] = useState('create'); // 'create' or 'edit'
  const [contractNumber, setContractNumber] = useState('');
  const [formDebtorName, setFormDebtorName] = useState('');
  const [formNik, setFormNik] = useState('');
  const [formCollateralType, setFormCollateralType] = useState('');
  const [savingModal, setSavingModal] = useState(false);
  const [contractOnlyMode, setContractOnlyMode] = useState(false);
  const [collateralMode, setCollateralMode] = useState(false);
  const [lastSavedContract, setLastSavedContract] = useState(null);
  const [collateralForm, setCollateralForm] = useState({
    contract_number: '',
    name_of_debtor: '',
    vechile_types: '',
    vechile_brand: '',
    vechile_model: '',
    plat_number: '',
    chasiss_number: '',
    engine_number: '',
    manufactured_year: '',
    colour: '',
    bpkb_number: '',
    name_bpkb_owner: ''
  });
  const [collateralSaving, setCollateralSaving] = useState(false);
  const [collateralError, setCollateralError] = useState('');

  const requestWithAuth = async (config) => {
    const doRequest = async (token) => {
      const headers = token ? { Authorization: `Bearer ${token}` } : {};
      return axios({ ...config, headers });
    };

    try {
      const access = localStorage.getItem('access_token');
      return await doRequest(access);
    } catch (err) {
      const respData = err?.response?.data || {};
      const isTokenExpired = respData.code === 'token_not_valid' || (respData.messages && Array.isArray(respData.messages) && respData.messages.some(m => m.message && m.message.toLowerCase().includes('expired')));
      if (err.response?.status === 401 || isTokenExpired) {
        try {
          const refresh = localStorage.getItem('refresh_token');
          if (!refresh) throw err;
          const r = await axios.post('http://localhost:8000/api/token/refresh/', { refresh });
          const newAccess = r.data.access;
          if (newAccess) {
            localStorage.setItem('access_token', newAccess);
            return await doRequest(newAccess);
          }
        } catch (refreshErr) {
          console.error('Token refresh failed', refreshErr);
          localStorage.removeItem('access_token');
          localStorage.removeItem('refresh_token');
          throw err;
        }
      }
      throw err;
    }
  };

  // Gaya field form lokal agar sesuai dengan form lain
  const fieldLabelStyle = { fontSize: 13, fontWeight: 600, color: '#333', marginBottom: 6 };
  const fieldInputStyle = { padding: '10px 12px', fontSize: 14, border: '1px solid #ddd', borderRadius: 6, outline: 'none', width: '100%', boxSizing: 'border-box' };
  const fieldGroupStyle = { display: 'flex', flexDirection: 'column' };

  useEffect(() => { loadAgreements(); }, []);

  const loadAgreements = async () => {
    setLoading(true);
    setError('');
    try {
      // Ambil data dari endpoint UV agreement
      const res = await requestWithAuth({ method: 'get', url: 'http://localhost:8000/api/uv-agreement/' });
      let items = res.data?.agreements || res.data?.results || res.data || [];
      if (!Array.isArray(items)) items = items ? [items] : [];
      // keep raw item plus some normalized convenience fields
      const rows = items.map(item => {
        // Prefer vehicle type fields from the TOP-LEVEL uv_agreement row (item)
        // so the table reflects columns from `uv_agreement` rather than nested collateral.
        const vehicleVal = item.vehicle_type || item.vechile_type || item.collateral_type || item.uv_collateral_type || ((item.collateral && (item.collateral.vehicle_types || item.collateral.vechile_types || item.collateral.collateral_type)) || '') ;
        const normalized = {
          agreement_date: item.agreement_date || item.header?.agreement_date || item.created_at || item.created || item.date_created || '',
          contract_number: item.contract_number || (item.contract && item.contract.contract_number) || '',
          name_of_debtor: (item.debtor || item.contract || {}).name_of_debtor || item.name_of_debtor || item.debtor_name || '',
          nik_number_of_debtor: (item.debtor || item.contract || {}).nik_number_of_debtor || item.nik_number_of_debtor || item.debtor_nik || '',
          collateral_type: vehicleVal,
          created_by: item.created_by || item.created_by_name || item.created_by_user || item.created_by_user_name || ''
        };
        return { raw: item, ...normalized };
      });
      setAgreements(rows);

      // determine dynamic columns from raw items (union of keys)
      const colsSet = new Set();
      items.forEach(it => {
        if (it && typeof it === 'object') Object.keys(it).forEach(k => colsSet.add(k));
      });
      // prefer a few known columns first
      const preferred = ['agreement_date', 'contract_number', 'name_of_debtor', 'nik_number_of_debtor', 'vehicle_types', 'vechile_types', 'collateral_type', 'created_by'];
      const dynamic = Array.from(colsSet).filter(c => !preferred.includes(c));
      let ordered = [...preferred.filter(p => colsSet.has(p)), ...dynamic];
      // Ensure `vehicle_types` column appears after `nik_number_of_debtor` even if
      // the physical column isn't present in uv_agreement (we derive it from nested collateral).
      if (!ordered.includes('vehicle_types')) {
        const insertAfter = ordered.indexOf('nik_number_of_debtor');
        if (insertAfter >= 0) {
          ordered = [...ordered.slice(0, insertAfter + 1), 'vehicle_types', ...ordered.slice(insertAfter + 1)];
        } else {
          // fallback: append near start
          ordered.splice(1, 0, 'vehicle_types');
        }
      }
      setColumns(ordered);
    } catch (err) {
      console.error('Error loading UV agreements', err);
      setError('Gagal memuat data UV Agreement');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = async (row) => {
    const cn = row.contract_number;
    setError('');
    if (!cn) {
      setModalMode('create'); setContractNumber(''); setFormDebtorName(''); setFormNik(''); setFormCollateralType(''); setShowCreateModal(true); return;
    }

    // Untuk Edit: JANGAN gabungkan nilai lokal — biarkan BLAgreement2 memuat semua data langsung
    setContractNumber(cn);
    setModalMode('edit');
    setShowCreateModal(true);
  };

  const fetchContractData = async (cn) => {
    try {
      const res = await requestWithAuth({ method: 'get', url: `http://localhost:8000/api/uv-agreement/?contract_number=${encodeURIComponent(cn)}` });
      // backend mengembalikan { debtor: ..., collateral: ... }
      return res.data || {};
    } catch (err) {
      console.error('Failed fetch contract', err);
      return {};
    }
  };

  const handleDownloadRow = async (row) => {
    if (!row.contract_number) { setError('Contract number not available'); return; }
    try {
      // Minta PDF jika tersedia
      const url = `http://localhost:8000/api/uv-agreement/download-docx/?contract_number=${encodeURIComponent(row.contract_number)}&as_pdf=1`;
      const res = await requestWithAuth({ method: 'get', url, responseType: 'blob' });
      const contentType = (res.headers && res.headers['content-type']) || '';
      const isPdf = contentType.includes('pdf') || url.toLowerCase().includes('as_pdf=1');
      const blob = new Blob([res.data], { type: contentType || (isPdf ? 'application/pdf' : 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') });
      const link = document.createElement('a');
      link.href = window.URL.createObjectURL(blob);
      link.download = `uv_agreement_${row.contract_number}${isPdf ? '.pdf' : '.docx'}`;
      document.body.appendChild(link);
      link.click(); link.remove();
    } catch (err) {
      console.error('Download failed', err); setError('Failed to download the document');
    }
  };

  const handleSaveModal = async () => {
    setSavingModal(true);
    try {
      const payload = { contract_number: contractNumber, debtor: { name_of_debtor: formDebtorName, nik_number_of_debtor: formNik }, collateral: { collateral_type: formCollateralType } };
      await requestWithAuth({ method: 'post', url: 'http://localhost:8000/api/uv-agreement/', data: payload });
      setShowCreateModal(false);
      await loadAgreements();
    } catch (err) {
      console.error('Save failed', err);
      setError('Failed to save');
    } finally {
      setSavingModal(false);
    }
  };

  const handleSaveAndDownload = async () => {
    setSavingModal(true);
    try {
      const payload = { contract_number: contractNumber, debtor: { name_of_debtor: formDebtorName, nik_number_of_debtor: formNik }, collateral: { collateral_type: formCollateralType } };
      await requestWithAuth({ method: 'post', url: 'http://localhost:8000/api/uv-agreement/', data: payload });
      // refresh daftar lalu unduh
      await loadAgreements();
      // Request PDF when available
      const url = `http://localhost:8000/api/uv-agreement/download-docx/?contract_number=${encodeURIComponent(contractNumber)}&as_pdf=1`;
      const res = await requestWithAuth({ method: 'get', url, responseType: 'blob' });
      const contentType = (res.headers && res.headers['content-type']) || '';
      const isPdf = contentType.includes('pdf') || url.toLowerCase().includes('as_pdf=1');
      const blob = new Blob([res.data], { type: contentType || (isPdf ? 'application/pdf' : 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') });
      const link = document.createElement('a'); link.href = window.URL.createObjectURL(blob); link.download = `uv_agreement_${contractNumber}${isPdf ? '.pdf' : '.docx'}`; document.body.appendChild(link); link.click(); link.remove();
      setShowCreateModal(false);
    } catch (err) {
      console.error('Save & Download failed', err);
      setError('Failed to save and download');
    } finally {
      setSavingModal(false);
    }
  };

  const handleModalDownload = async () => {
    if (!contractNumber) { setError('Contract number is empty'); return; }
    try {
      // Request PDF when available
      const url = `http://localhost:8000/api/uv-agreement/download-docx/?contract_number=${encodeURIComponent(contractNumber)}&as_pdf=1`;
      const res = await requestWithAuth({ method: 'get', url, responseType: 'blob' });
      const contentType = (res.headers && res.headers['content-type']) || '';
      const isPdf = contentType.includes('pdf') || url.toLowerCase().includes('as_pdf=1');
      const blob = new Blob([res.data], { type: contentType || (isPdf ? 'application/pdf' : 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') });
      const link = document.createElement('a'); link.href = window.URL.createObjectURL(blob); link.download = `uv_agreement_${contractNumber}${isPdf ? '.pdf' : '.docx'}`; document.body.appendChild(link); link.click(); link.remove();
    } catch (err) { console.error('Download failed', err); setError('Failed to download the document'); }
  };

  const formatDateShort = (iso) => {
    if (!iso) return '';
    try { const d = new Date(iso); if (isNaN(d.getTime())) return iso; const dd = String(d.getDate()).padStart(2, '0'); const mm = String(d.getMonth() + 1).padStart(2, '0'); const yyyy = d.getFullYear(); return `${dd}-${mm}-${yyyy}`; } catch (e) { return iso; }
  };

  return (
    <div>
      <div>
        <h2>UV Agreement</h2>
        <p>Before creating the document, make sure to fill in the contract and collateral data first.</p>
      </div>

      <div className="user-management-actions" style={{ justifyContent: 'flex-end', marginTop: 0 }}>
        <button
          className="btn-primary"
          onClick={() => { setModalMode('create'); setContractNumber(''); setFormDebtorName(''); setFormNik(''); setFormCollateralType(''); setError(''); setContractOnlyMode(true); setShowCreateModal(true); }}
          title="Add a new contract"
        >
          Add Contract
        </button>

        <button
          className="btn-primary"
          onClick={() => { setModalMode('create'); setContractNumber(''); setFormDebtorName(''); setFormNik(''); setFormCollateralType(''); setError(''); setCollateralMode(true); setShowCreateModal(true); }}
          title="Add a new UV collateral"
        >
          Add UV Collateral
        </button>

        <button className="btn-save" onClick={() => { setModalMode('create'); setContractNumber(''); setFormDebtorName(''); setFormNik(''); setFormCollateralType(''); setError(''); setContractOnlyMode(false); setCollateralMode(false); setShowCreateModal(true); }}>Create Document</button>
      </div>

      <div className="user-table-section" style={{ marginTop: 12 }}>
        <div style={{ padding: 12 }}>
          

          {loading ? (
            <div>Loading...</div>
          ) : error ? (
            <div className="error-message">{error}</div>
          ) : (
            <div style={{ overflowX: 'auto' }}>
              <table className="user-table">
                <thead>
                  <tr>
                    {columns.length === 0 ? (
                      <>
                        <th>Agreement Date</th>
                        <th>Contract Number</th>
                        <th>Name of Debtor</th>
                        <th>NIK Debtor</th>
                        <th>Vehicle Types</th>
                        <th>Created By</th>
                      </>
                    ) : (
                      columns.map(col => {
                        const displayName = (col === 'collateral_type' || col === 'vehicle_types' || col === 'vechile_types') ? 'Vehicle Types' : col.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
                        return <th key={col}>{displayName}</th>;
                      })
                    )}
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {agreements.length === 0 ? (
                    <tr><td className="no-data" colSpan={columns.length + 1 || 7}>No agreements found.</td></tr>
                  ) : (
                    agreements.map((row) => (
                      <tr key={row.contract_number || JSON.stringify(row.raw).slice(0, 40)}>
                        {(columns.length === 0 ? [
                          <td key="ad">{formatDateShort(row.agreement_date)}</td>,
                          <td key="cn">{row.contract_number}</td>,
                          <td key="nd">{row.name_of_debtor}</td>,
                          <td key="nik">{row.nik_number_of_debtor}</td>,
                          <td key="ct">{row.collateral_type}</td>,
                          <td key="cb">{row.created_by}</td>
                        ] : columns.map(col => {
                          // prefer normalized field for known convenience keys
                          let val = undefined;
                          if (col === 'agreement_date' || col === 'contract_number' || col === 'name_of_debtor' || col === 'nik_number_of_debtor' || col === 'created_by') {
                            val = row[col];
                          } else if (col === 'vehicle_types' || col === 'vechile_types' || col === 'collateral_type') {
                            val = row.collateral_type || row.raw && (row.raw.vehicle_types || row.raw.vechile_types || row.raw.collateral_type);
                          } else {
                            val = row.raw && (row.raw[col] !== undefined ? row.raw[col] : row[col]);
                          }
                          if (col.toLowerCase().includes('date') && val) return <td key={col}>{formatDateShort(val)}</td>;
                          return <td key={col}>{(val === null || val === undefined) ? '' : String(val)}</td>;
                        }))}
                        <td>
                          <div style={{ display: 'flex', gap: 8 }}>
                            <button className="btn-edit" onClick={() => handleEdit(row)}>Edit</button>
                            <button className="btn-cancel" onClick={() => handleDownloadRow(row)}>Download</button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {showCreateModal && (
        <div className="modal-overlay" onClick={() => { setShowCreateModal(false); setContractOnlyMode(false); setCollateralMode(false); }}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
              <div className="modal-header">
              <h3 className="modal-title">
                {modalMode === 'edit' && contractNumber ? `Edit ${contractNumber}` : (
                  contractOnlyMode ? 'Add Contract' : (collateralMode ? 'Add UV Collateral' : 'Create Document')
                )}
              </h3>
              <button className="modal-close-btn" onClick={() => { setShowCreateModal(false); setContractOnlyMode(false); setCollateralMode(false); }}>&times;</button>
            </div>

            <div className="modal-form">
              {modalMode === 'edit' ? (
                <UVAgreementEdit
                  initialContractNumber={contractNumber}
                  onSaved={(cn) => { setShowCreateModal(false); setContractOnlyMode(false); loadAgreements(); if (cn) setContractNumber(cn); }}
                />
              ) : collateralMode ? (
                <div style={{ padding: 20, minWidth: 560 }}>
                  <h3 style={{ marginTop: 0 }}>Add UV Collateral</h3>
                  {collateralError && <div style={{ marginBottom: 12, color: '#a33' }}>{collateralError}</div>}

                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                    <div style={fieldGroupStyle}>
                      <label style={fieldLabelStyle}>Contract Number</label>
                      <input
                        type="text"
                        value={collateralForm.contract_number}
                        onChange={async (e) => {
                          const v = e.target.value;
                          setCollateralForm(prev => ({ ...prev, contract_number: v }));
                          if (v && v.trim()) {
                            try {
                              const data = await fetchContractData(v.trim());
                              const debtor = data.debtor || data || {};
                              const debtorName = debtor.name_of_debtor || debtor.name || '';
                              setCollateralForm(prev => ({ ...prev, name_of_debtor: debtorName }));
                            } catch (err) {
                              setCollateralForm(prev => ({ ...prev, name_of_debtor: '' }));
                            }
                          } else {
                            setCollateralForm(prev => ({ ...prev, name_of_debtor: '' }));
                          }
                        }}
                        style={fieldInputStyle}
                      />
                    </div>
                    
                    <div style={fieldGroupStyle}>
                      <label style={fieldLabelStyle}>Name of Debtor</label>
                      <input type="text" value={collateralForm.name_of_debtor} disabled style={{ ...fieldInputStyle, backgroundColor: '#f5f5f5' }} />
                    </div>

                    <div style={fieldGroupStyle}>
                      <label style={fieldLabelStyle}>Vehicle Types</label>
                      <input type="text" value={collateralForm.vechile_types} onChange={(e) => setCollateralForm(prev => ({ ...prev, vechile_types: e.target.value }))} style={fieldInputStyle} />
                    </div>

                    <div style={fieldGroupStyle}>
                      <label style={fieldLabelStyle}>Vehicle Brand</label>
                      <input type="text" value={collateralForm.vechile_brand} onChange={(e) => setCollateralForm(prev => ({ ...prev, vechile_brand: e.target.value }))} style={fieldInputStyle} />
                    </div>

                    <div style={fieldGroupStyle}>
                      <label style={fieldLabelStyle}>Vehicle Model</label>
                      <input type="text" value={collateralForm.vechile_model} onChange={(e) => setCollateralForm(prev => ({ ...prev, vechile_model: e.target.value }))} style={fieldInputStyle} />
                    </div>

                    <div style={fieldGroupStyle}>
                      <label style={fieldLabelStyle}>Plate Number</label>
                      <input type="text" value={collateralForm.plat_number} onChange={(e) => setCollateralForm(prev => ({ ...prev, plat_number: e.target.value }))} style={fieldInputStyle} />
                    </div>

                    <div style={fieldGroupStyle}>
                      <label style={fieldLabelStyle}>Chassis Number</label>
                      <input type="text" value={collateralForm.chasiss_number} onChange={(e) => setCollateralForm(prev => ({ ...prev, chasiss_number: e.target.value }))} style={fieldInputStyle} />
                    </div>

                    <div style={fieldGroupStyle}>
                      <label style={fieldLabelStyle}>Engine Number</label>
                      <input type="text" value={collateralForm.engine_number} onChange={(e) => setCollateralForm(prev => ({ ...prev, engine_number: e.target.value }))} style={fieldInputStyle} />
                    </div>

                    <div style={fieldGroupStyle}>
                      <label style={fieldLabelStyle}>Manufactured Year</label>
                      <input type="text" value={collateralForm.manufactured_year} onChange={(e) => setCollateralForm(prev => ({ ...prev, manufactured_year: e.target.value }))} style={fieldInputStyle} />
                    </div>

                    <div style={fieldGroupStyle}>
                      <label style={fieldLabelStyle}>Colour</label>
                      <input type="text" value={collateralForm.colour} onChange={(e) => setCollateralForm(prev => ({ ...prev, colour: e.target.value }))} style={fieldInputStyle} />
                    </div>

                    <div style={fieldGroupStyle}>
                      <label style={fieldLabelStyle}>BPKB Number</label>
                      <input type="text" value={collateralForm.bpkb_number} onChange={(e) => setCollateralForm(prev => ({ ...prev, bpkb_number: e.target.value }))} style={fieldInputStyle} />
                    </div>

                    <div style={fieldGroupStyle}>
                      <label style={fieldLabelStyle}>Name BPKB Owner</label>
                      <input type="text" value={collateralForm.name_bpkb_owner} onChange={(e) => setCollateralForm(prev => ({ ...prev, name_bpkb_owner: e.target.value }))} style={fieldInputStyle} />
                    </div>
                  </div>

                  <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 16 }}>
                    <button className="btn-save" onClick={async () => {
                      setCollateralSaving(true); setCollateralError('');
                      try {
                        // Validate contract_number presence to avoid inserting empty PK -> 0
                        const cn = (collateralForm.contract_number || '').toString().trim();
                        if (!cn) {
                          setCollateralError('Contract Number is required');
                          setCollateralSaving(false);
                          return;
                        }
                        // Build collateral payload and send under `collateral` key as backend expects
                        const collPayload = buildCollateralPayload({ ...collateralForm, contract_number: cn }, 'uv');
                        // ensure we send top-level contract_number and nested collateral object
                        const postData = { contract_number: cn, collateral: collPayload };
                        await requestWithAuth({ method: 'post', url: 'http://localhost:8000/api/uv-collateral/', data: postData });
                        setShowCreateModal(false);
                        setCollateralMode(false);
                        loadAgreements();
                        setSuccessMessage('Collateral data saved successfully');
                        setTimeout(() => setSuccessMessage(''), 4000);
                      } catch (err) {
                        console.error('Save collateral failed', err);
                        const msg = err?.response?.data?.error || 'Failed to save collateral';
                        setCollateralError(msg);
                      } finally {
                        setCollateralSaving(false);
                      }
                    }} disabled={collateralSaving}>{collateralSaving ? 'Saving...' : 'Save Collateral'}</button>
                  </div>
                </div>
              ) : (
                <UVAgreementCreate
                  initialContractData={lastSavedContract}
                  contractOnly={contractOnlyMode}
                  onContractSaved={(saved) => {
                    // Jika pengguna membatalkan entri kontrak, tutup modal
                    if (!saved) {
                      setShowCreateModal(false);
                      setContractOnlyMode(false);
                      return;
                    }
                    // Setelah menyimpan kontrak: tutup modal, refresh daftar, tampilkan notifikasi sukses
                    setLastSavedContract(saved || null);
                    setShowCreateModal(false);
                    setContractOnlyMode(false);
                    loadAgreements();
                    setSuccessMessage('Contract data saved successfully');
                    // hapus otomatis pesan sukses setelah 4 detik
                    setTimeout(() => setSuccessMessage(''), 4000);
                  }}
                  onSaved={(cn) => { setShowCreateModal(false); setContractOnlyMode(false); loadAgreements(); if (cn) setContractNumber(cn); }}
                />
              )}
            </div>

            {/* modal footer intentionally left without a bottom Cancel/Close button per UI preference */}
          </div>
        </div>
      )}

      
    </div>
  );
}
