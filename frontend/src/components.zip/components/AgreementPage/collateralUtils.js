// Helper to build collateral payloads for different agreement types (BL vs UV)
export function buildCollateralPayload(form = {}, type = 'uv') {
  // Normalize input
  const f = form || {};
  if (type === 'uv') {
    // UV collateral: prefer vehicle-specific keys, DO NOT include `collateral_type`
    const out = {
      contract_number: f.contract_number || undefined,
      vechile_types: f.vechile_types || f.vehicle_types || undefined,
      vehicle_types: f.vechile_types || f.vehicle_types || undefined,
      vechile_brand: f.vechile_brand || undefined,
      vechile_model: f.vechile_model || undefined,
      plat_number: f.plat_number || undefined,
      chasiss_number: f.chasiss_number || undefined,
      engine_number: f.engine_number || undefined,
      manufactured_year: f.manufactured_year || undefined,
      colour: f.colour || undefined,
      bpkb_number: f.bpkb_number || undefined,
      name_bpkb_owner: f.name_bpkb_owner || undefined
    };
    // remove empty/undefined string fields to avoid inserting '' -> 0 on numeric PK
    Object.keys(out).forEach(k => {
      const v = out[k];
      if (v === undefined) delete out[k];
      else if (typeof v === 'string' && v.trim() === '') delete out[k];
      else if (v === null) delete out[k];
    });
    return out;
  }

  // Default / BL: include general collateral_type and common fields, omit vehicle-specific typos
  return {
    contract_number: f.contract_number || undefined,
    collateral_type: f.collateral_type || f.vechile_types || f.vehicle_types || undefined,
    number_of_certificate: f.number_of_certificate || '',
    number_of_ajb: f.number_of_ajb || '',
    surface_area: f.surface_area || '',
    name_of_collateral_owner: f.name_of_collateral_owner || '',
    capacity_of_building: f.capacity_of_building || '',
    location_of_land: f.location_of_land || ''
  };
}

export default buildCollateralPayload;
