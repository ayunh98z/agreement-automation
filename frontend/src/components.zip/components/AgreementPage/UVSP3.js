import React from 'react';

function UVSP3() {
  return (
    <div className="agreement-content">
      <h2>UV SP3</h2>
      <p>Before creating the document, make sure to fill in the contract and collateral data first.</p>
      <p>Belum huhuhu.</p>
    </div>
  );
}

export default UVSP3;
